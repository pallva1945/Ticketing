
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import AboutSection from './components/AboutSection';
import TeamSection from './components/TeamSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import TimelineSection from './components/TimelineSection';
import PartnersSection from './components/PartnersSection';
import ProductsSection from './components/ProductsSection';

const App: React.FC = () => {
  return (
    <div className="bg-white text-varese-dark font-sans">
      <Header />
      <main>
        <Hero />
        <AboutSection />
        <TimelineSection />
        <ProductsSection />
        <TeamSection />
        <PartnersSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default App;