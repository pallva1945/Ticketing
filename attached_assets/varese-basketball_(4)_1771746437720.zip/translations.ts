import {
  ClockIcon,
  DumbbellIcon,
  FilmIcon,
  BedIcon,
  FlameIcon,
  BarChartIcon
} from './constants';
import React from 'react';

export const translations = {
  en: {
    languageSwitcher: {
      ariaLabel: 'Switch to Italian'
    },
    header: {
      navLinks: [
        { href: '#about', label: 'About' },
        { href: '#journey', label: 'Journey' },
        { href: '#products', label: 'Products' },
        { href: '#team', label: 'Team' },
        { href: '#sponsors', label: 'Sponsors' },
        { href: '#contact', label: 'Contact' },
      ],
    },
    hero: {
      title: {
        part1: 'The ',
        highlight: 'Dream',
        part2: ' Factory'
      },
      subtitle: 'The official youth program of Pallacanestro Varese. We identify and develop the next generation of talent, turning passion into profession and dreams into reality.',
      imageAlt: 'Varese Basketball team huddle',
    },
    aboutSection: {
      title: 'A Storied History',
      subtitle: 'More than just a team',
      sectionTitle: 'The Pride of Pallacanestro Varese',
      content: 'Varese Basketball is the modern chapter of a legendary story. We are built on the foundation of Pallacanestro Varese, one of the most decorated clubs in European basketball history—a name that resonates with excellence, dedication, and an unyielding passion for the game. Our trophy case tells a story of dominance:',
      achievements: [
        { count: 10, title: 'Italian Leagues' },
        { count: 5, title: 'EuroLeague Titles' },
        { count: 2, title: 'Saporta Cups' },
        { count: 3, title: 'Intercontinental Cups' },
      ],
      legacy: 'This tradition of victory inspires our mission today: to discover and forge the next generation of champions, continuing our legacy of greatness for years to come.',
      imageAlt: 'Historic Varese Basketball moment',
      prevImage: 'Previous image',
      nextImage: 'Next image',
      goToImage: 'Go to image',
    },
    timelineSection: {
        title: "Our Journey",
        subtitle: "From Vision to Victory",
        prevImage: "Previous image",
        nextImage: "Next image",
        goToImage: "Go to image",
        started: {
            title: "Where We Started: A New Beginning",
            p1: "When we took over in 2021, the club's youth operations were managed by a third party, leaving us with no players under our direct development. We knew a radical change was necessary to build a true powerhouse.",
            p2: "One year later, we made a decisive move: we broke ties with the external company and founded Varese Basketball. Our first step was to forge a strategic alliance with Robur et Fides, another historic basketball program in the city, accelerating our mission to cultivate elite talent from the ground up.",
            imageAlt: "Strategic Alliance Handshake"
        },
        are: {
            title: "Where We Are: Building a Powerhouse",
            trainingCenter: {
                title: "First-Class Training Center",
                description: "A €300,000 investment to create a state-of-the-art environment for player development."
            },
            residence: {
                title: "Elite Player Residence",
                description: "A €2M investment in a top-notch residence with 25 double rooms, a private chef, and an on-site tutor."
            },
            video: {
                title: "See Our World in Motion",
                iframeTitle: "Varese Basketball Showcase"
            },
            journeyStats: [
                { value: '450', label: 'Kids in Program (7-21)' },
                { value: '19', label: 'Elite Group Players' },
                { value: '15', label: 'Players in Full-Time Residence' },
                { value: '6', label: 'Eccellenza Teams' },
                { value: '9', label: 'Full-Time Coaches (6 Youth, 3 Serie A)' },
                { value: '4', label: 'Part-Time Coaches' },
                { value: '2', label: 'Full-Time S&C Coaches' },
                { value: '2', label: 'Part-Time S&C Coaches' },
                { value: '4', label: 'Physiotherapists' },
            ],
            dataDriven: {
                title: "A Data-Driven Approach to Development",
                description: "We don't guess; we measure. Our comprehensive database provides unparalleled insights into player performance and growth.",
                features: [
                    'Daily load and shot tracking for every elite player.',
                    'Advanced stats with integrated game video analysis.',
                    'Anthropometric measurements and growth projections.',
                    'Physical performance testing and monitoring.',
                    'Tailor-made "Player Pack" programs for elite individuals.',
                ],
                imageAlt1: "Shot tracking data",
                imageAlt2: "Player pack"
            },
            proPlayers: {
                title: "From Our Factory to the Pros",
                players: [
                    { name: 'Elisee Asui', team: 'Serie A (Varese)' },
                    { name: 'Matteo Librizzi', team: 'Serie A (Varese Captain)' },
                    { name: 'Mauro Villa', team: 'Serie A (Varese)' },
                    { name: 'Niccolò Virginio', team: 'Serie A2' },
                    { name: 'Christian Kouassi', team: 'Serie B1' },
                ],
                footer: "...and this is just the beginning."
            }
        },
        next: {
            title: "What's Next",
            subtitle: "Pushing the Boundaries of Development",
            lab: {
                tag: "Imminent Arrival",
                title: "Pallacanestro Varese Lab by Ivolution",
                description: "Our commitment to innovation takes its next step. This cutting-edge sports science and biomechanics facility is poised to become the most advanced in Italy, solidifying our leadership in player development.",
                funding: {
                    title: "Funding Status: 70% Complete",
                    description: "This project is 70% funded through our own resources, and we are finalizing strategic partnerships to cover the remainder. No external capital injection is required."
                },
                downloadButton: "Download Brochure",
                reelAriaLabel: "Watch the reel for Pallacanestro Varese Lab by Ivolution",
                imageAlt: "Pallacanestro Varese Lab",
                reelButton: "Watch the Reel"
            },
            vision: {
                title: "The Next Big Leap: A €3M Vision for the Future",
                description: "Looking ahead, our most ambitious project is a complete €3 million revitalization of our training facility. This transformative initiative requires external investment and is an open invitation for partners to join us in building a world-class basketball ecosystem.",
                renderAlt: "Training Facility Revitalization Render",
                scope: {
                    title: "Project Scope",
                    items: [
                        "Complete restructuring of the main training facility.",
                        "New professional offices, elite locker rooms, and advanced recovery zones.",
                        "800 square meters of prime, integrated commercial space."
                    ]
                },
                tech: {
                    title: "Vanguard Technology",
                    description: "At its core will be technology from Kinexon and Rspct, capturing 400+ real-time data points on every movement and shot—displayed on a giant courtside screen for immediate, deep analysis.",
                    metrics: "Metrics include: speed, jumping, acceleration, shot type, location, parabola, and alignment.",
                    imageAlt1: "Kinexon technology in action",
                    imageAlt2: "Rspct technology setup",
                    imageAlt3: "Rspct shot tracking interface",
                    imageAlt4: "Kinexon data visualization on court"
                },
                cta: {
                    title: "Creating an NBA-Caliber Environment",
                    description: "These pivotal investments will elevate our data-driven methods to a level only comparable with top NBA organizations. We are actively seeking visionary partners to help fund this project and shape the future of European basketball.",
                    button: "Discuss Partnership"
                }
            }
        },
        ourMethod: {
            title: "Our Method: Win the Day",
            description: "Every day is an opportunity. Our philosophy is built on a relentless, daily commitment to excellence in every aspect of a player's life.",
            everyday: "Everyday",
            winTheDay: "We Win the Day.",
            steps: [
                {
                    icon: React.createElement(ClockIcon, { className: "h-10 w-10" }),
                    title: 'We Show Up',
                    description: 'Hard work is our foundation. With customized practices and tailor-made programs from 7 am to 10 pm, we instill the discipline it takes to make it to the pros. We show up, every day, and get it done.',
                    images: ['https://lh3.googleusercontent.com/d/13fY5_QqvYoMzuEwRZK_yZ50ZJuaB2kvK'],
                },
                {
                    icon: React.createElement(DumbbellIcon, { className: "h-10 w-10" }),
                    title: 'We Improve',
                    description: 'Fundamentals are key. Our daily "Vitamins"—individual skill sessions with a max of 3 players per basket and 2 coaches—ensure constant improvement in dribbling, shooting, strength, and more.',
                    images: [
                        'https://lh3.googleusercontent.com/d/1NB6qbdltmzmwDxHAHmHlYcLVl1Kq9boh',
                        'https://lh3.googleusercontent.com/d/1_W8lER3fB65kkMBlDqBEqAucKe60bVcp',
                        'https://lh3.googleusercontent.com/d/185jcdOqZsVMSmnX_ZGZw06yMCtevh_0h',
                    ],
                },
                {
                    icon: React.createElement(FilmIcon, { className: "h-10 w-10" }),
                    title: 'We Study',
                    description: 'Both coaches and players use our advanced stats and integrated video analysis platform to study the game, identify opportunities for growth, and become more effective on the court.',
                    images: ['https://i.imgur.com/6PiNMEq.png'],
                },
                {
                    icon: React.createElement(BedIcon, { className: "h-10 w-10" }),
                    title: 'We Recover',
                    description: 'Our top-notch residence, complete with an entertainment zone and a private chef, provides the perfect environment to recover, sleep, and connect with teammates, enjoying the best of Italian cuisine.',
                    images: [
                        'https://lh3.googleusercontent.com/d/119ewkXzaigtXa7_yG6zg1JPl1Rpvn2uc',
                        'https://lh3.googleusercontent.com/d/1GY1kiLzt9u9wyCi5Ppk6AN9aff2ajh2j',
                    ],
                },
                {
                    icon: React.createElement(FlameIcon, { className: "h-10 w-10" }),
                    title: 'We Compete',
                    description: 'With 6 Eccellenza teams and a dedicated Serie B team for youth, we provide a unique playing platform that offers the crucial game experience needed to implement and test newly developed skills.',
                    images: [
                        'https://lh3.googleusercontent.com/d/1TGLxaIUgoehUjLxG4Pyj_P0ABigz0Y8b',
                        'https://lh3.googleusercontent.com/d/1PxC_5lW6EMxiaHwuW5ImgbNAMT4g5adY',
                    ],
                },
                {
                    icon: React.createElement(BarChartIcon, { className: "h-10 w-10" }),
                    title: 'We Track',
                    description: 'We track everything: practice intensity, shots, game performance, and physical growth. With monthly tests and advanced stats, we ensure that if it can be measured, it can be improved.',
                    images: [
                        'https://i.imgur.com/1M2vonH.png',
                        'https://i.imgur.com/aqb8ON6.png',
                        'https://i.imgur.com/pd0Q8pv.png',
                        'https://i.imgur.com/Z8yTdTC.png',
                    ],
                },
            ]
        },
        going: {
            title: "Where We're Going",
            description: 'Our vision is simple but ambitious: To become, together, the <span class="text-varese-red font-semibold">best youth program in Italy.</span>'
        }
    },
    productsSection: {
      title: 'Our Products',
      subtitle: 'Comprehensive Development Pathways',
      tabs: [
          { id: 'players', label: 'For Players' },
          { id: 'pros', label: 'For Pros' },
          { id: 'coaches', label: 'For Coaches' },
          { id: 'teams', label: 'For Teams (Summer)' },
          { id: 'front-office', label: 'For Front Office' },
      ],
      modal: {
        thankYou: "Thank You!",
        submittedMsg: "Your inquiry has been sent. We'll get back to you shortly.",
        title: "Inquire Now",
        inquiryType: "Regarding:",
        nameLabel: "Full Name",
        emailLabel: "Email Address",
        messageLabel: "Your Question",
        submitButton: "Send Inquiry",
        closeAriaLabel: "Close contact form"
      },
      players: {
        title: "Full-Time Year-Round Program",
        description: "Leveraging our extensive NBA and Euroleague experience, we offer an unparalleled year-round program designed to guide players on the path to elite basketball and maximize their exposure.",
        target: { title: "Target Audience", details: "Ages 13-17 (under 15 ideal for Italian Player Status)" },
        timing: { title: "Timing", details: "End of August to End of June" },
        opportunity: { title: "Future Opportunity", details: "Acquire Italian Player Status and eligibility for the National Team." },
        completeOffer: {
            title: "The Complete Offer",
            pillars: [
                { title: 'Elite Basketball', description: 'Daily individual and team sessions focused on technical and physical development, monitored with advanced stats and video analysis to create a tailored program for each player.' },
                { title: 'Holistic Education', description: 'A pillar of our program, we offer a range of educational paths including public, private, and online schools to ensure a perfect balance of basketball and study.' },
                { title: 'Premium Room & Board', description: 'Newly constructed dorms just a 5-minute walk from our facilities, featuring a private chef, dedicated laundry, private gardens, and weekly cleaning service.' },
            ]
        },
        trainingProgram: {
            title: "Our 360° Training Program",
            pillars: [
                { title: 'Fundamentals', details: 'Shooting / Playmaking / Dribbling / Finishing' },
                { title: 'Strength & Conditioning', details: 'Strength Dev / Power / Speed / Agility / Stamina' },
                { title: 'Treatment/Recovery', details: 'Injury Prevention / Workload Management / Rehabilitation' },
                { title: 'Sports Science', details: 'Catapult / Pushband / Inertial' },
                { title: 'Basketball Leadership', details: 'Leadership Skills / Mental Conditioning' },
                { title: 'Basketball Analysis', details: 'Advanced Performance Analysis / Advanced Boxscore / Big Data' },
            ],
            teaching: '<strong class="text-varese-dark">1. Teaching:</strong> Periodic analysis sessions to gain insights from performance data.',
            personalization: '<strong class="text-varese-dark">2. Personalization:</strong> Tailored practice plans for targeted, efficient development.',
            feedback: '<strong class="text-varese-dark">3. Feedback:</strong> Weekly reports to foster collaborative progress evaluation.'
        },
        growthPlan: {
            title: "Program Growth Plan",
            years: [
                { year: 'Year 1', players: '2-4 Players' },
                { year: 'Year 2', players: '4-6 Players' },
                { year: 'Year 3', players: '6-8 Players' },
                { year: 'Year 4', players: '8 Players' },
            ],
            note: "Based on Italian Basketball Federation rules, we believe 8 is the maximum number of players to maintain an elite level of operation for this program."
        },
        cta: {
            title: "Ready to Join the Next Generation?",
            subtitle: "Find out more about our Full-Time Program and begin your journey.",
            button: "Inquire Now"
        },
        prevImageAria: 'Previous image',
        nextImageAria: 'Next image',
        goToImageAria: 'Go to image'
      },
      pros: {
        title: "10 Elite Hours Package",
        description: "For dedicated players who can't get enough. This year-round package provides 10 hours of intensive, individual, and tailor-made skill training to elevate your game.",
        target: { title: "Target Audience", details: "Aspiring pros or any dedicated athlete seeking extra development." },
        timing: { title: "Timing", details: "Year-round with flexible scheduling to fit your professional or personal calendar." },
        included: {
            title: "What's Included",
            features: [
                { title: 'Elite 1-on-1 Coaching', description: 'Work directly with our Serie A and youth coaching staff to refine your skills.' },
                { title: 'Tailor-Made Skill Work', description: 'A personalized training regimen focusing on your specific needs, from shooting mechanics to decision-making.' },
                { title: 'Advanced Video Analysis', description: 'Break down your game film with our experts to identify areas for improvement and track progress.' },
                { title: 'Pro-Level Facilities', description: 'Train in our state-of-the-art gym, weight room, and recovery areas.' },
                { title: 'Flexible Scheduling', description: 'We work around your schedule to provide training when you need it most, year-round.' },
                { title: 'Performance Tracking', description: 'Utilize our technology to get data-driven feedback on your performance and development.' }
            ]
        },
        cta: {
            title: "Don't Just Practice. Train with Purpose.",
            subtitle: "Take the next step. Inquire about our 10 Elite Hours Package today.",
            button: "Inquire Now"
        }
      },
      coaches: {
        title: "Coaches Internship Program",
        description: "An unparalleled opportunity for ambitious international coaches to gain firsthand experience within a professional Serie A coaching staff and immerse themselves in the world of elite European basketball.",
        target: { title: "Target Audience", details: "Young, ambitious coaches with a basketball coaching license." },
        timing: { title: "Timing & Duration", details: "LBA Season (Aug-Jun), 1-month minimum commitment." },
        offer: {
            title: "The All-Inclusive Offer",
            items: [
                { title: "Housing", details: ["Newly renovated (2024) housing", "Single room occupancy", "5-minute walk from training facility"] },
                { title: "Food", details: ["3 Meals a Day", "Freshly Made by Italian Chefs", "Sports Nutrition-Driven Menus"] },
                { title: "Coaching", details: ["Shadow coaching", "Coaching clinics", "Player Scouting"] },
            ]
        },
        experience: {
            title: "The Experience",
            items: [
                "Gain firsthand experience integrated into our Serie A coaching staff.",
                "Participate in coaches' meetings and gain strategic insights.",
                "Take an active role on the court, running drills with our players.",
                "Assist our youth teams' coaching staff to develop future stars.",
                "Attend Serie A practices and games.",
                "Utilize Hudl for advanced video analysis."
            ]
        },
        results: {
            title: "The Results",
            items: [
                "Develop your coaching acumen in a professional Serie A environment.",
                "Acquire invaluable knowledge and practical skills from our staff.",
                "Enhance your resume with a prestigious internship.",
                "Expand your professional network within European basketball."
            ]
        },
        cta: {
            title: "Ready to Elevate Your Coaching Career?",
            subtitle: "Apply for our elite internship program and learn from the best.",
            button: "Inquire Now"
        }
      },
      teams: {
        title: "Summer Elite Program",
        description: "Designed to elevate your team's skills during the offseason, we offer a fully customizable, all-inclusive training camp experience at our elite facilities.",
        target: { title: "Target Audience", details: "Youth National Teams (U14-U18), Junior Programs, and Medium-Level Senior Teams." },
        timing: { title: "Timing", details: "Minimum 1 week (7 days, 6 nights), based on availability and team needs." },
        baseOffer: {
            title: "All-Inclusive Base Offer",
            items: [
                { title: "Accommodation", details: ["6 double rooms, 2 single rooms", "Spacious dining & relaxation areas", "Two 300 mq private gardens"] },
                { title: "Food", details: ["Breakfast, Lunch & Dinner", "Personalized, sports-focused catering", "Dietary restrictions accommodated"] },
                { title: "Facility Exclusivity", details: ["3h/day exclusive use (9am-12pm)", "Basketball court & locker room", "Weight, recovery & therapy areas"] },
                { title: "Transportation", details: ["Airport pick-up & drop-off", "2 comfortable 9-seat vans", "Stress-free travel logistics"] },
            ]
        },
        aLaCarte: {
            title: "Build Your Own Week: A La Carte Services",
            services: [
                { title: "Housing", price: "€40", unit: "Person/Day", details: ["Min 10 players", "Min 1 week stay"] },
                { title: "Food", price: "€30", unit: "Person/Day", details: ["Breakfast", "Lunch & Dinner"] },
                { title: "Transports", price: "€2,50", unit: "KM/Van", details: ["2 vans available", "Min 50€/van"] },
                { title: "Facilities", price: "€400", unit: "Half Day", details: ["Court, weight & recovery room", "Locker room included"] },
            ]
        },
        addOns: {
            title: "Optional Add-On Services",
            services: [
                { title: 'Professional Services', price: '€50 DAY/COACH' },
                { title: 'Elite Coaching', price: 'TBD' },
                { title: 'Advisory', price: 'TBD' },
                { title: 'Tourism', price: 'TBD' },
                { title: 'Concierge Services', price: 'TBD' },
                { title: 'Arena', price: 'TBD' },
            ],
            note: "Additional tourist options to discover Milan, Como, and more are also available upon request."
        },
        cta: {
            title: "Customize Your Perfect Training Camp",
            subtitle: "Contact us to tailor a package that meets your team's specific needs and goals.",
            button: "Inquire Now"
        }
      },
      frontOffice: {
        title: "Front Office Consulting",
        description: "Leverage our deep knowledge and experience from the NBA and Euroleague to give your organization a significant competitive edge. We provide strategic guidance to federations, national teams, and clubs.",
        target: { title: "Target Audience", details: "Federations, National Teams, and Clubs." },
        timing: { title: "Timing", details: "Year-round partnership and advisory." },
        services: {
            title: "Our Consulting Services",
            items: [
                { title: "Academy", details: ["Consulting", "Business plan", "Naming"] },
                { title: "National Team", details: ["Advisory (5-10 hours remote)", "Follow-ups (4 one-week trips/year)", "Decision Making (Coaching staff, etc.)"] },
                { title: "Analytics", details: ["Our Database", "Analysis, Reports, Playing Style", "Resource Sharing (Software, HR, Time)"] },
            ]
        },
        advantages: {
            title: "Key Partnership Advantages",
            items: [
                { title: "Sharing of Human Resources", description: "Coaches can serve both the national team and PV staff, lowering costs and maximizing playing style synergies. A remote Analysis & Research department can also be established." },
                { title: "Software and Subscriptions", description: "By unifying Research & Analytics resources, the cost of data storage, maintenance, and technology implementation is significantly reduced." },
                { title: "Bilateral Crossover Games", description: "Both PV and the partner national team or clubs benefit from traveling for friendly games, pre-tournament warm-ups, and preseason matches." },
            ]
        },
        cta: {
            title: "Build a Winning Organization",
            subtitle: "Partner with us to implement elite strategies and systems.",
            button: "Inquire Now"
        }
      }
    },
    teamSection: {
      title: 'Meet the Team',
      subtitle: 'The people behind the passion',
      intro: {
        p1: 'Our leadership is a unique blend of global basketball acumen, seasoned business expertise, and deep local roots. At the heart of our basketball operations, Zach, Luis, and Maksim bring a formidable combination of over 25 years in the NBA and an additional 20 years of global basketball experience, providing unparalleled strategic insight.',
        p2: 'Guiding our vision, Paolo and Antonio contribute unmatchable business expertise from diverse industries worldwide. Our connection to the community is strengthened by leaders like Federico, a former player who speaks four languages and masterfully engages our fanbase, and Marco, whose 25 years in sales have given him an intimate understanding of our community\'s pulse.',
      },
      seniorAdvisorsTitle: 'Senior Advisors',
      eliteLeadershipTitle: 'Elite Leadership Group',
      SeniorAdvisors: [
        { name: 'Luis Scola', role: 'Project Leader', imageUrl: 'https://i.imgur.com/SKmIitK.png', description: 'Former professional basketball player with 10 years in the NBA and 10 in Euroleague. Olympian.' },
        { name: 'Paolo Perego', role: 'Board Vice President', imageUrl: 'https://i.imgur.com/XBjtZsK.png', description: '20+ years as an executive manager in international companies. Active board member in elite Italian companies.' },
        { name: 'Antonio Bulgheroni', role: 'Team President', imageUrl: 'https://i.imgur.com/9CGmKy6.png', description: 'Former player, owner, and president of Pallacanestro Varese. Won 2 Euroleagues as a player and the last Scudetto as owner. Former CEO and President of Lindt & Sprüngli Italy.' },
      ],
      EliteLeadership: [
        { name: 'Zach Sogolow', role: 'General Manager, Basketball Operations and COO', imageUrl: 'https://i.imgur.com/wHVwtM7.png', description: 'Harvard graduate. Spent 4 years in the NBA league office and 4 years with the Philadelphia 76ers.' },
        { name: 'Maksim Horowitz', role: 'General Manager and Chief Strategy Officer', imageUrl: 'https://i.imgur.com/jAMPp3V.png', description: 'Carnegie Mellon University graduate. Spent 2.5 years in the NBA league office and 5 years with the Atlanta Hawks.' },
        { name: 'Marco Zamberletti', role: 'Sales Chief Officer', imageUrl: 'https://i.imgur.com/lRgRD1m.png', description: 'With Pallacanestro Varese since 1999, working across sales, marketing, and ticketing.' },
        { name: 'Federico Bellotto', role: 'CEO Varese Basketball', imageUrl: 'https://i.imgur.com/3lFQ9uQ.png', description: 'Fluent in four languages. Holds three international diplomas in Sports Business and Management. Former youth player of Pallacanestro Varese.' },
      ],
    },
    partnersSection: {
        title: "Our Sponsors",
        subtitle: "United in Pursuit of Excellence"
    },
    contactSection: {
      title: 'Get in Touch',
      subtitle: "We're ready to talk",
      description: "Whether you're a prospective player, potential sponsor, investor, coach, or a member of the media, we'd love to hear from you. Reach out to us to discuss how we can work together.",
      categories: ['Player', 'Sponsor', 'Investor', 'Coach', 'Media'],
      modal: {
        thankYou: 'Thank You!',
        submittedMsg: "Your message has been sent. We'll get back to you shortly.",
        title: 'Contact Us',
        inquiryType: 'Inquiry from a potential',
        nameLabel: 'Full Name',
        emailLabel: 'Email Address',
        messageLabel: 'Message',
        submitButton: 'Send Message',
        closeAriaLabel: 'Close contact form',
      },
    },
    footer: {
      copyright: 'Pallacanestro Varese. All rights reserved.',
    },
  },
  it: {
    languageSwitcher: {
      ariaLabel: 'Passa all\'inglese'
    },
    header: {
      navLinks: [
        { href: '#about', label: 'Chi Siamo' },
        { href: '#journey', label: 'Percorso' },
        { href: '#products', label: 'Prodotti' },
        { href: '#team', label: 'Team' },
        { href: '#sponsors', label: 'Sponsor' },
        { href: '#contact', label: 'Contatti' },
      ],
    },
    hero: {
      title: {
        part1: 'La Fabbrica dei ',
        highlight: 'Sogni',
        part2: ''
      },
      subtitle: 'Il programma giovanile ufficiale di Pallacanestro Varese. Identifichiamo e sviluppiamo la prossima generazione di talenti, trasformando la passione in professione e i sogni in realtà.',
      imageAlt: 'La squadra di Varese Basketball in cerchio',
    },
    aboutSection: {
      title: 'Una Storia Gloriosa',
      subtitle: 'Più di una semplice squadra',
      sectionTitle: 'L\'Orgoglio di Pallacanestro Varese',
      content: 'Varese Basketball è il capitolo moderno di una storia leggendaria. Siamo costruiti sulle fondamenta di Pallacanestro Varese, uno dei club più decorati nella storia del basket europeo, un nome che risuona di eccellenza, dedizione e una passione incrollabile per il gioco. La nostra bacheca racconta una storia di dominio:',
      achievements: [
        { count: 10, title: 'Scudetti' },
        { count: 5, title: 'Titoli Eurolega' },
        { count: 2, title: 'Coppe Saporta' },
        { count: 3, title: 'Coppe Intercontinentali' },
      ],
      legacy: 'Questa tradizione di vittoria ispira la nostra missione odierna: scoprire e forgiare la prossima generazione di campioni, continuando la nostra eredità di grandezza per gli anni a venire.',
      imageAlt: 'Momento storico di Varese Basketball',
      prevImage: 'Immagine precedente',
      nextImage: 'Immagine successiva',
      goToImage: 'Vai all\'immagine',
    },
    timelineSection: {
        title: "Il Nostro Percorso",
        subtitle: "Dalla Visione alla Vittoria",
        prevImage: "Immagine precedente",
        nextImage: "Immagine successiva",
        goToImage: "Vai all'immagine",
        started: {
            title: "Dove Abbiamo Iniziato: Un Nuovo Inizio",
            p1: "Quando abbiamo preso il controllo nel 2021, le operazioni giovanili del club erano gestite da terzi, lasciandoci senza giocatori sotto il nostro sviluppo diretto. Sapevamo che era necessario un cambiamento radicale per costruire una vera potenza.",
            p2: "Un anno dopo, abbiamo fatto una mossa decisiva: abbiamo rotto i legami con la società esterna e fondato Varese Basketball. Il nostro primo passo è stato forgiare un'alleanza strategica con Robur et Fides, un altro programma storico di basket della città, accelerando la nostra missione di coltivare talenti d'élite fin dalle fondamenta.",
            imageAlt: "Stretta di mano per l'alleanza strategica"
        },
        are: {
            title: "Dove Siamo Ora: Costruendo una Potenza",
            trainingCenter: {
                title: "Centro di Allenamento di Prima Classe",
                description: "Un investimento di 300.000 € per creare un ambiente all'avanguardia per lo sviluppo dei giocatori."
            },
            residence: {
                title: "Residenza per Giocatori d'Élite",
                description: "Un investimento di 2 milioni di euro in una residenza di prim'ordine con 25 camere doppie, uno chef privato e un tutor in loco."
            },
            video: {
                title: "Guarda il Nostro Mondo in Movimento",
                iframeTitle: "Vetrina di Varese Basketball"
            },
            journeyStats: [
                { value: '450', label: 'Ragazzi nel Programma (7-21)' },
                { value: '19', label: 'Giocatori del Gruppo Élite' },
                { value: '15', label: 'Giocatori in Residenza a Tempo Pieno' },
                { value: '6', label: 'Squadre di Eccellenza' },
                { value: '9', label: 'Allenatori a Tempo Pieno (6 Giov., 3 Serie A)' },
                { value: '4', label: 'Allenatori Part-Time' },
                { value: '2', label: 'Prep. Fisici a Tempo Pieno' },
                { value: '2', label: 'Prep. Fisici Part-Time' },
                { value: '4', label: 'Fisioterapisti' },
            ],
            dataDriven: {
                title: "Un Approccio allo Sviluppo Basato sui Dati",
                description: "Non tiriamo a indovinare; misuriamo. Il nostro database completo fornisce approfondimenti senza pari sulle prestazioni e sulla crescita dei giocatori.",
                features: [
                    'Monitoraggio giornaliero del carico e del tiro per ogni giocatore d\'élite.',
                    'Statistiche avanzate con analisi video integrata delle partite.',
                    'Misure antropometriche e proiezioni di crescita.',
                    'Test e monitoraggio delle prestazioni fisiche.',
                    'Programmi "Player Pack" su misura per individui d\'élite.',
                ],
                imageAlt1: "Dati di monitoraggio del tiro",
                imageAlt2: "Player pack"
            },
            proPlayers: {
                title: "Dalla Nostra Fabbrica ai Professionisti",
                players: [
                    { name: 'Elisee Asui', team: 'Serie A (Varese)' },
                    { name: 'Matteo Librizzi', team: 'Serie A (Capitano Varese)' },
                    { name: 'Mauro Villa', team: 'Serie A (Varese)' },
                    { name: 'Niccolò Virginio', team: 'Serie A2' },
                    { name: 'Christian Kouassi', team: 'Serie B1' },
                ],
                footer: "...e questo è solo l'inizio."
            }
        },
        next: {
            title: "Cosa C'è Dopo",
            subtitle: "Spingendo i Confini dello Sviluppo",
            lab: {
                tag: "Arrivo Imminente",
                title: "Pallacanestro Varese Lab by Ivolution",
                description: "Il nostro impegno per l'innovazione fa il suo prossimo passo. Questa struttura all'avanguardia di scienza dello sport e biomeccanica è destinata a diventare la più avanzata d'Italia, consolidando la nostra leadership nello sviluppo dei giocatori.",
                funding: {
                    title: "Stato Finanziamento: 70% Completato",
                    description: "Questo progetto è finanziato al 70% con risorse proprie e stiamo finalizzando partnership strategiche per coprire il resto. Non è richiesta alcuna iniezione di capitale esterno."
                },
                downloadButton: "Scarica la Brochure",
                reelAriaLabel: "Guarda il reel per Pallacanestro Varese Lab by Ivolution",
                imageAlt: "Pallacanestro Varese Lab",
                reelButton: "Guarda il Reel"
            },
            vision: {
                title: "Il Prossimo Grande Salto: Una Visione da 3M€ per il Futuro",
                description: "Guardando al futuro, il nostro progetto più ambizioso è una rivitalizzazione completa da 3 milioni di euro della nostra struttura di allenamento. Questa iniziativa trasformativa richiede investimenti esterni ed è un invito aperto ai partner a unirsi a noi nella costruzione di un ecosistema di basket di livello mondiale.",
                renderAlt: "Render della Ristrutturazione della Struttura di Allenamento",
                scope: {
                    title: "Scopo del Progetto",
                    items: [
                        "Ristrutturazione completa della struttura di allenamento principale.",
                        "Nuovi uffici professionali, spogliatoi d'élite e zone di recupero avanzate.",
                        "800 metri quadrati di spazio commerciale di pregio e integrato."
                    ]
                },
                tech: {
                    title: "Tecnologia all'Avanguardia",
                    description: "Al centro ci sarà la tecnologia di Kinexon e Rspct, che catturerà oltre 400 punti dati in tempo reale su ogni movimento e tiro, visualizzati su un gigantesco schermo a bordo campo per un'analisi immediata e approfondita.",
                    metrics: "Le metriche includono: velocità, salto, accelerazione, tipo di tiro, posizione, parabola e allineamento.",
                    imageAlt1: "Tecnologia Kinexon in azione",
                    imageAlt2: "Configurazione della tecnologia Rspct",
                    imageAlt3: "Interfaccia di tracciamento del tiro Rspct",
                    imageAlt4: "Visualizzazione dati Kinexon in campo"
                },
                cta: {
                    title: "Creare un Ambiente di Calibro NBA",
                    description: "Questi investimenti cruciali eleveranno i nostri metodi basati sui dati a un livello paragonabile solo alle migliori organizzazioni NBA. Stiamo cercando attivamente partner visionari per aiutare a finanziare questo progetto e plasmare il futuro del basket europeo.",
                    button: "Discuti Partnership"
                }
            }
        },
        ourMethod: {
            title: "Il Nostro Metodo: Vinci la Giornata",
            description: "Ogni giorno è un'opportunità. La nostra filosofia si basa su un impegno quotidiano e implacabile per l'eccellenza in ogni aspetto della vita di un giocatore.",
            everyday: "Ogni giorno",
            winTheDay: "Vinciamo la Giornata.",
            steps: [
                {
                    icon: React.createElement(ClockIcon, { className: "h-10 w-10" }),
                    title: 'Ci Presentiamo',
                    description: 'Il duro lavoro è la nostra base. Con allenamenti personalizzati e programmi su misura dalle 7:00 alle 22:00, infondiamo la disciplina necessaria per arrivare ai professionisti. Ci presentiamo, ogni giorno, e facciamo il nostro dovere.',
                    images: ['https://lh3.googleusercontent.com/d/13fY5_QqvYoMzuEwRZK_yZ50ZJuaB2kvK'],
                },
                {
                    icon: React.createElement(DumbbellIcon, { className: "h-10 w-10" }),
                    title: 'Miglioriamo',
                    description: 'I fondamentali sono la chiave. Le nostre "Vitamine" quotidiane — sessioni di abilità individuali con un massimo di 3 giocatori per canestro e 2 allenatori — assicurano un miglioramento costante nel palleggio, nel tiro, nella forza e altro ancora.',
                    images: [
                        'https://lh3.googleusercontent.com/d/1NB6qbdltmzmwDxHAHmHlYcLVl1Kq9boh',
                        'https://lh3.googleusercontent.com/d/1_W8lER3fB65kkMBlDqBEqAucKe60bVcp',
                        'https://lh3.googleusercontent.com/d/185jcdOqZsVMSmnX_ZGZw06yMCtevh_0h',
                    ],
                },
                {
                    icon: React.createElement(FilmIcon, { className: "h-10 w-10" }),
                    title: 'Studiamo',
                    description: 'Sia gli allenatori che i giocatori utilizzano le nostre statistiche avanzate e la piattaforma di analisi video integrata per studiare il gioco, identificare opportunità di crescita e diventare più efficaci in campo.',
                    images: ['https://i.imgur.com/6PiNMEq.png'],
                },
                {
                    icon: React.createElement(BedIcon, { className: "h-10 w-10" }),
                    title: 'Recuperiamo',
                    description: 'La nostra residenza di prim\'ordine, completa di una zona di intrattenimento e uno chef privato, offre l\'ambiente perfetto per recuperare, dormire e connettersi con i compagni di squadra, godendo del meglio della cucina italiana.',
                    images: [
                        'https://lh3.googleusercontent.com/d/119ewkXzaigtXa7_yG6zg1JPl1Rpvn2uc',
                        'https://lh3.googleusercontent.com/d/1GY1kiLzt9u9wyCi5Ppk6AN9aff2ajh2j',
                    ],
                },
                {
                    icon: React.createElement(FlameIcon, { className: "h-10 w-10" }),
                    title: 'Competiamo',
                    description: 'Con 6 squadre di Eccellenza e una squadra di Serie B dedicata ai giovani, forniamo una piattaforma di gioco unica che offre l\'esperienza cruciale necessaria per implementare e testare le nuove abilità sviluppate.',
                    images: [
                        'https://lh3.googleusercontent.com/d/1TGLxaIUgoehUjLxG4Pyj_P0ABigz0Y8b',
                        'https://lh3.googleusercontent.com/d/1PxC_5lW6EMxiaHwuW5ImgbNAMT4g5adY',
                    ],
                },
                {
                    icon: React.createElement(BarChartIcon, { className: "h-10 w-10" }),
                    title: 'Tracciamo',
                    description: 'Tracciamo tutto: intensità degli allenamenti, tiri, prestazioni in partita e crescita fisica. Con test mensili e statistiche avanzate, ci assicuriamo che se può essere misurato, può essere migliorato.',
                    images: [
                        'https://i.imgur.com/1M2vonH.png',
                        'https://i.imgur.com/aqb8ON6.png',
                        'https://i.imgur.com/pd0Q8pv.png',
                        'https://i.imgur.com/Z8yTdTC.png',
                    ],
                },
            ]
        },
        going: {
            title: "Dove Stiamo Andando",
            description: 'La nostra visione è semplice ma ambiziosa: diventare, insieme, il <span class="text-varese-red font-semibold">miglior programma giovanile d\'Italia.</span>'
        }
    },
    productsSection: {
      title: 'I Nostri Prodotti',
      subtitle: 'Percorsi di Sviluppo Completi',
      tabs: [
          { id: 'players', label: 'Per Giocatori' },
          { id: 'pros', label: 'Per Professionisti' },
          { id: 'coaches', label: 'Per Allenatori' },
          { id: 'teams', label: 'Per Squadre (Estivo)' },
          { id: 'front-office', label: 'Per Dirigenti' },
      ],
      modal: {
        thankYou: "Grazie!",
        submittedMsg: "La tua richiesta è stata inviata. Ti risponderemo a breve.",
        title: "Richiedi Informazioni",
        inquiryType: "Riguardo a:",
        nameLabel: "Nome Completo",
        emailLabel: "Indirizzo Email",
        messageLabel: "La tua Domanda",
        submitButton: "Invia Richiesta",
        closeAriaLabel: "Chiudi modulo di contatto"
      },
      players: {
        title: "Programma Annuale a Tempo Pieno",
        description: "Sfruttando la nostra vasta esperienza in NBA ed Eurolega, offriamo un programma annuale senza pari, progettato per guidare i giocatori sulla strada del basket d'élite e massimizzare la loro visibilità.",
        target: { title: "A Chi è Rivolto", details: "Età 13-17 (sotto i 15 ideale per lo status di giocatore italiano)" },
        timing: { title: "Periodo", details: "Da fine agosto a fine giugno" },
        opportunity: { title: "Opportunità Futura", details: "Acquisire lo status di giocatore italiano e l'eleggibilità per la Nazionale." },
        completeOffer: {
            title: "L'Offerta Completa",
            pillars: [
                { title: 'Pallacanestro d\'Elitè', description: 'Sessioni giornaliere individuali e di squadra focalizzate sullo sviluppo tecnico e fisico, monitorate con statistiche avanzate e analisi video per creare un programma su misura per ogni giocatore.' },
                { title: 'Istruzione Olistica', description: 'Un pilastro del nostro programma, offriamo una gamma di percorsi educativi tra cui scuole pubbliche, private e online per garantire un equilibrio perfetto tra basket e studio.' },
                { title: 'Vitto e Alloggio Premium', description: 'Dormitori di nuova costruzione a soli 5 minuti a piedi dalle nostre strutture, con chef privato, lavanderia dedicata, giardini privati e servizio di pulizia settimanale.' },
            ]
        },
        trainingProgram: {
            title: "Il Nostro Programma di Allenamento a 360°",
            pillars: [
                { title: 'Fondamentali', details: 'Tiro / Creazione di gioco / Palleggio / Finalizzazione' },
                { title: 'Forza e Condizionamento', details: 'Sviluppo Forza / Potenza / Velocità / Agilità / Resistenza' },
                { title: 'Trattamento/Recupero', details: 'Prevenzione Infortuni / Gestione Carico / Riabilitazione' },
                { title: 'Scienze Motorie', details: 'Catapult / Pushband / Inerziale' },
                { title: 'Leadership Cestistica', details: 'Capacità di Leadership / Preparazione Mentale' },
                { title: 'Analisi Cestistica', details: 'Analisi Prestazioni Avanzata / Boxscore Avanzato / Big Data' },
            ],
            teaching: '<strong class="text-varese-dark">1. Insegnamento:</strong> Sessioni di analisi periodiche per ottenere spunti dai dati sulle prestazioni.',
            personalization: '<strong class="text-varese-dark">2. Personalizzazione:</strong> Piani di allenamento su misura per uno sviluppo mirato ed efficiente.',
            feedback: '<strong class="text-varese-dark">3. Feedback:</strong> Report settimanali per promuovere una valutazione collaborativa dei progressi.'
        },
        growthPlan: {
            title: "Piano di Crescita del Programma",
            years: [
                { year: 'Anno 1', players: '2-4 Giocatori' },
                { year: 'Anno 2', players: '4-6 Giocatori' },
                { year: 'Anno 3', players: '6-8 Giocatori' },
                { year: 'Anno 4', players: '8 Giocatori' },
            ],
            note: "In base alle regole della Federazione Italiana Pallacanestro, crediamo che 8 sia il numero massimo di giocatori per mantenere un livello operativo d'élite per questo programma."
        },
        cta: {
            title: "Pronto a Unirti alla Prossima Generazione?",
            subtitle: "Scopri di più sul nostro Programma a Tempo Pieno e inizia il tuo viaggio.",
            button: "Richiedi Informazioni"
        },
        prevImageAria: 'Immagine precedente',
        nextImageAria: 'Immagine successiva',
        goToImageAria: 'Vai all\'immagine'
      },
      pros: {
        title: "Pacchetto 10 Ore d'Élite",
        description: "Per i giocatori appassionati che non ne hanno mai abbastanza. Questo pacchetto annuale offre 10 ore di allenamento intensivo, individuale e su misura per elevare il tuo gioco.",
        target: { title: "A Chi è Rivolto", details: "Aspiranti professionisti o qualsiasi atleta dedicato che cerca uno sviluppo extra." },
        timing: { title: "Periodo", details: "Tutto l'anno con programmazione flessibile per adattarsi al tuo calendario professionale o personale." },
        included: {
            title: "Cosa è Incluso",
            features: [
                { title: 'Coaching d\'Élite 1-on-1', description: 'Lavora direttamente con il nostro staff tecnico di Serie A e giovanile per affinare le tue abilità.' },
                { title: 'Lavoro Tecnico su Misura', description: 'Un regime di allenamento personalizzato incentrato sulle tue esigenze specifiche, dalla meccanica di tiro al processo decisionale.' },
                { title: 'Analisi Video Avanzata', description: 'Analizza i tuoi filmati di gioco con i nostri esperti per identificare aree di miglioramento e monitorare i progressi.' },
                { title: 'Strutture di Livello Professionistico', description: 'Allenati nella nostra palestra, sala pesi e aree di recupero all\'avanguardia.' },
                { title: 'Programmazione Flessibile', description: 'Lavoriamo intorno ai tuoi impegni per fornire allenamento quando ne hai più bisogno, tutto l\'anno.' },
                { title: 'Monitoraggio delle Prestazioni', description: 'Utilizza la nostra tecnologia per ottenere feedback basati sui dati sulle tue prestazioni e sviluppo.' }
            ]
        },
        cta: {
            title: "Non Allenarti Soltanto. Allenati con uno Scopo.",
            subtitle: "Fai il passo successivo. Richiedi oggi informazioni sul nostro Pacchetto 10 Ore d'Élite.",
            button: "Richiedi Informazioni"
        }
      },
      coaches: {
        title: "Programma di Tirocinio per Allenatori",
        description: "Un'opportunità senza pari per ambiziosi allenatori internazionali di acquisire esperienza diretta all'interno di uno staff tecnico professionistico di Serie A e immergersi nel mondo del basket europeo d'élite.",
        target: { title: "A Chi è Rivolto", details: "Giovani e ambiziosi allenatori con una licenza di allenatore di pallacanestro." },
        timing: { title: "Periodo e Durata", details: "Stagione LBA (Ago-Giu), impegno minimo di 1 mese." },
        offer: {
            title: "L'Offerta All-Inclusive",
            items: [
                { title: "Alloggio", details: ["Alloggi recentemente rinnovati (2024)", "Stanza singola", "A 5 minuti a piedi dalla struttura di allenamento"] },
                { title: "Vitto", details: ["3 Pasti al Giorno", "Preparati freschi da chef italiani", "Menu orientati alla nutrizione sportiva"] },
                { title: "Coaching", details: ["Shadow coaching", "Clinic per allenatori", "Scouting di giocatori"] },
            ]
        },
        experience: {
            title: "L'Esperienza",
            items: [
                "Acquisisci esperienza diretta integrato nel nostro staff tecnico di Serie A.",
                "Partecipa alle riunioni degli allenatori e ottieni spunti strategici.",
                "Assumi un ruolo attivo in campo, conducendo esercitazioni con i nostri giocatori.",
                "Assisti lo staff tecnico delle nostre squadre giovanili per sviluppare le future stelle.",
                "Partecipa agli allenamenti e alle partite di Serie A.",
                "Utilizza Hudl per analisi video avanzate."
            ]
        },
        results: {
            title: "I Risultati",
            items: [
                "Sviluppa la tua acume da allenatore in un ambiente professionale di Serie A.",
                "Acquisisci conoscenze inestimabili e competenze pratiche dal nostro staff.",
                "Migliora il tuo curriculum con un tirocinio prestigioso.",
                "Espandi la tua rete professionale nel basket europeo."
            ]
        },
        cta: {
            title: "Pronto a Elevare la Tua Carriera da Allenatore?",
            subtitle: "Candidati per il nostro programma di tirocinio d'élite e impara dai migliori.",
            button: "Richiedi Informazioni"
        }
      },
      teams: {
        title: "Programma Estivo d'Élite",
        description: "Progettato per elevare le abilità della tua squadra durante la offseason, offriamo un'esperienza di training camp completamente personalizzabile e all-inclusive presso le nostre strutture d'élite.",
        target: { title: "A Chi è Rivolto", details: "Nazionali Giovanili (U14-U18), Programmi Junior e Squadre Senior di Medio Livello." },
        timing: { title: "Periodo", details: "Minimo 1 settimana (7 giorni, 6 notti), in base alla disponibilità e alle esigenze della squadra." },
        baseOffer: {
            title: "Offerta Base All-Inclusive",
            items: [
                { title: "Alloggio", details: ["6 camere doppie, 2 camere singole", "Ampie aree pranzo e relax", "Due giardini privati di 300 mq"] },
                { title: "Vitto", details: ["Colazione, Pranzo e Cena", "Catering personalizzato e sportivo", "Restrizioni dietetiche gestite"] },
                { title: "Esclusività della Struttura", details: ["Uso esclusivo 3h/giorno (9-12)", "Campo da basket e spogliatoio", "Aree pesi, recupero e terapia"] },
                { title: "Trasporti", details: ["Trasferimento da/per aeroporto", "2 comodi van da 9 posti", "Logistica di viaggio senza stress"] },
            ]
        },
        aLaCarte: {
            title: "Costruisci la Tua Settimana: Servizi A La Carte",
            services: [
                { title: "Alloggio", price: "€40", unit: "Persona/Giorno", details: ["Min 10 giocatori", "Min 1 settimana"] },
                { title: "Vitto", price: "€30", unit: "Persona/Giorno", details: ["Colazione", "Pranzo e Cena"] },
                { title: "Trasporti", price: "€2,50", unit: "KM/Van", details: ["2 van disponibili", "Min 50€/van"] },
                { title: "Strutture", price: "€400", unit: "Mezza Giornata", details: ["Campo, sala pesi e recupero", "Spogliatoio incluso"] },
            ]
        },
        addOns: {
            title: "Servizi Aggiuntivi Opzionali",
            services: [
                { title: 'Servizi Professionali', price: '€50 GIORNO/COACH' },
                { title: 'Coaching d\'Élite', price: 'Da definire' },
                { title: 'Consulenza', price: 'Da definire' },
                { title: 'Turismo', price: 'Da definire' },
                { title: 'Servizi di Concierge', price: 'Da definire' },
                { title: 'Palazzetto', price: 'Da definire' },
            ],
            note: "Opzioni turistiche aggiuntive per scoprire Milano, Como e altro sono disponibili su richiesta."
        },
        cta: {
            title: "Personalizza il Tuo Training Camp Perfetto",
            subtitle: "Contattaci per creare un pacchetto su misura che soddisfi le esigenze e gli obiettivi specifici della tua squadra.",
            button: "Richiedi Informazioni"
        }
      },
      frontOffice: {
        title: "Consulenza per Dirigenti",
        description: "Sfrutta la nostra profonda conoscenza ed esperienza dall'NBA e dall'Eurolega per dare alla tua organizzazione un significativo vantaggio competitivo. Forniamo guida strategica a federazioni, squadre nazionali e club.",
        target: { title: "A Chi è Rivolto", details: "Federazioni, Squadre Nazionali e Club." },
        timing: { title: "Periodo", details: "Partnership e consulenza per tutto l'anno." },
        services: {
            title: "I Nostri Servizi di Consulenza",
            items: [
                { title: "Academy", details: ["Consulenza", "Business plan", "Naming"] },
                { title: "Nazionale", details: ["Consulenza (5-10 ore remote)", "Follow-up (4 viaggi di una settimana/anno)", "Processo decisionale (Staff tecnico, ecc.)"] },
                { title: "Analytics", details: ["Il Nostro Database", "Analisi, Report, Stile di gioco", "Condivisione Risorse (Software, HR, Tempo)"] },
            ]
        },
        advantages: {
            title: "Vantaggi Chiave della Partnership",
            items: [
                { title: "Condivisione di Risorse Umane", description: "Gli allenatori possono servire sia la nazionale che lo staff di PV, riducendo i costi e massimizzando le sinergie di stile di gioco. Può essere istituito anche un dipartimento remoto di Analisi e Ricerca." },
                { title: "Software e Abbonamenti", description: "Unificando le risorse di Ricerca e Analisi, il costo di archiviazione dati, manutenzione e implementazione tecnologica si riduce significativamente." },
                { title: "Partite Amichevoli Bilaterali", description: "Sia PV che la nazionale o i club partner beneficiano di viaggi per partite amichevoli, riscaldamenti pre-torneo e partite di preseason." },
            ]
        },
        cta: {
            title: "Costruisci un'Organizzazione Vincente",
            subtitle: "Collabora con noi per implementare strategie e sistemi d'élite.",
            button: "Richiedi Informazioni"
        }
      }
    },
    teamSection: {
      title: 'Incontra il Team',
      subtitle: 'Le persone dietro la passione',
      intro: {
        p1: 'La nostra leadership è una miscela unica di acume cestistico globale, consolidata esperienza aziendale e profonde radici locali. Al cuore delle nostre operazioni cestistiche, Zach, Luis e Maksim portano una formidabile combinazione di oltre 25 anni in NBA e altri 20 anni di esperienza cestistica globale, fornendo una visione strategica senza pari.',
        p2: 'Guidando la nostra visione, Paolo e Antonio contribuiscono con un\'incomparabile competenza aziendale proveniente da diversi settori in tutto il mondo. Il nostro legame con la comunità è rafforzato da leader come Federico, un ex giocatore che parla quattro lingue e coinvolge magistralmente la nostra fanbase, e Marco, i cui 25 anni nelle vendite gli hanno dato una profonda comprensione del polso della nostra comunità.',
      },
      seniorAdvisorsTitle: 'Consiglieri Senior',
      eliteLeadershipTitle: 'Gruppo di Leadership d\'Élite',
      SeniorAdvisors: [
        { name: 'Luis Scola', role: 'Project Leader', imageUrl: 'https://i.imgur.com/SKmIitK.png', description: 'Ex giocatore di basket professionista con 10 anni in NBA e 10 in Eurolega. Olimpionico.' },
        { name: 'Paolo Perego', role: 'Vice Presidente del Consiglio', imageUrl: 'https://i.imgur.com/XBjtZsK.png', description: 'Oltre 20 anni come dirigente in aziende internazionali. Membro attivo del consiglio di amministrazione in aziende italiane d\'élite.' },
        { name: 'Antonio Bulgheroni', role: 'Presidente della Squadra', imageUrl: 'https://i.imgur.com/9CGmKy6.png', description: 'Ex giocatore, proprietario e presidente di Pallacanestro Varese. Ha vinto 2 Euroleghe da giocatore e l\'ultimo Scudetto da proprietario. Ex CEO e Presidente di Lindt & Sprüngli Italia.' },
      ],
      EliteLeadership: [
        { name: 'Zach Sogolow', role: 'General Manager, Basketball Operations e COO', imageUrl: 'https://i.imgur.com/wHVwtM7.png', description: 'Laureato ad Harvard. Ha trascorso 4 anni nell\'ufficio della lega NBA e 4 anni con i Philadelphia 76ers.' },
        { name: 'Maksim Horowitz', role: 'General Manager e Chief Strategy Officer', imageUrl: 'https://i.imgur.com/jAMPp3V.png', description: 'Laureato alla Carnegie Mellon University. Ha trascorso 2.5 anni nell\'ufficio della lega NBA e 5 anni con gli Atlanta Hawks.' },
        { name: 'Marco Zamberletti', role: 'Responsabile Commerciale', imageUrl: 'https://i.imgur.com/lRgRD1m.png', description: 'Con Pallacanestro Varese dal 1999, lavorando in vendite, marketing e biglietteria.' },
        { name: 'Federico Bellotto', role: 'CEO Varese Basketball', imageUrl: 'https://i.imgur.com/3lFQ9uQ.png', description: 'Fluente in quattro lingue. Possiede tre diplomi internazionali in Sports Business and Management. Ex giocatore giovanile di Pallacanestro Varese.' },
      ],
    },
    partnersSection: {
        title: "I Nostri Sponsor",
        subtitle: "Uniti nella Ricerca dell'Eccellenza"
    },
    contactSection: {
      title: 'Contattaci',
      subtitle: 'Siamo pronti a parlare',
      description: 'Che tu sia un futuro giocatore, un potenziale sponsor, un investitore, un allenatore o un membro dei media, ci piacerebbe sentirti. Contattaci per discutere di come possiamo collaborare.',
      categories: ['Giocatore', 'Sponsor', 'Investitore', 'Allenatore', 'Media'],
      modal: {
        thankYou: 'Grazie!',
        submittedMsg: 'Il tuo messaggio è stato inviato. Ti risponderemo al più presto.',
        title: 'Contattaci',
        inquiryType: 'Richiesta da un potenziale',
        nameLabel: 'Nome Completo',
        emailLabel: 'Indirizzo Email',
        messageLabel: 'Messaggio',
        submitButton: 'Invia Messaggio',
        closeAriaLabel: 'Chiudi il modulo di contatto',
      },
    },
    footer: {
      copyright: 'Pallacanestro Varese. Tutti i diritti riservati.',
    },
  }
};