import React, { useState, useEffect } from 'react';
import SectionTitle from './SectionTitle';
import {
  BasketballIcon,
  ScienceIcon,
  DumbbellIcon,
  LeadershipIcon,
  RecoveryIcon,
  BarChartIcon,
  CloseIcon,
  BedIcon,
  FoodIcon,
  CoachingIcon,
  EducationIcon,
  TransportationIcon,
  BriefcaseIcon,
  GlobeIcon,
  ClockIcon,
  ChevronLeftIcon,
  ChevronRightIcon
} from '../constants';
import { useLanguage } from '../contexts/LanguageContext';

// Contact Form Modal Component
interface ContactFormModalProps {
  category: string;
  onClose: () => void;
}

const ContactFormModal: React.FC<ContactFormModalProps> = ({ category, onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { texts } = useLanguage();
  const t = texts.productsSection.modal;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({ category, name, email, message });
    setIsSubmitted(true);
    setTimeout(() => {
        onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-2xl p-8 max-w-lg w-full relative transform transition-all duration-300 ease-in-out scale-95 animate-scale-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors rounded-full focus-visible:ring-2 focus-visible:ring-varese-red focus-visible:ring-offset-2"
          aria-label={t.closeAriaLabel}
        >
          <CloseIcon className="h-6 w-6" />
        </button>
        
        {isSubmitted ? (
            <div className="text-center py-8">
                <h3 className="text-2xl font-bold text-varese-dark mb-2">{t.thankYou}</h3>
                <p className="text-gray-600">{t.submittedMsg}</p>
            </div>
        ) : (
            <>
                <h3 className="text-2xl font-bold text-varese-dark mb-2">{t.title}</h3>
                <p className="text-varese-red font-semibold mb-6">{t.inquiryType} {category}</p>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">{t.nameLabel}</label>
                    <input type="text" name="name" id="name" required value={name} onChange={(e) => setName(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-varese-red focus:border-varese-red" />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">{t.emailLabel}</label>
                    <input type="email" name="email" id="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-varese-red focus:border-varese-red" />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700">{t.messageLabel}</label>
                    <textarea name="message" id="message" rows={4} required value={message} onChange={(e) => setMessage(e.target.value)} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-varese-red focus:border-varese-red" />
                  </div>
                  <div>
                    <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-varese-red hover:bg-red-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red transition-colors">
                      {t.submitButton}
                    </button>
                  </div>
                </form>
            </>
        )}
      </div>
       <style>{`
          @keyframes scale-in { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
          .animate-scale-in { animation: scale-in 0.2s ease-out forwards; }
       `}</style>
    </div>
  );
};

const trainingProgramImages = [
  'https://lh3.googleusercontent.com/d/1nE3Yq_Mo6jeEUDwPGYWnQmlh0gWdxkX7',
  'https://lh3.googleusercontent.com/d/1z5KcFRX3jM_LoB7bMXRBQpzxiwvWrvLr',
  'https://lh3.googleusercontent.com/d/1AFcTt4Ur-Q0gGIgnS2pQJPOtyIt9T1ty',
  'https://lh3.googleusercontent.com/d/1f2UZLChb9LZsE45JiXfrptgEERoZryRE',
  'https://lh3.googleusercontent.com/d/1eCDTzvm7jI6ise-0HkJXVbK3VkUak3_A',
  'https://lh3.googleusercontent.com/d/171k8Vsng6hW4L5GujaaP59THXPbbTzql',
];

const PlayerProgram: React.FC<{ onInquire: () => void }> = ({ onInquire }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const { texts } = useLanguage();
    const t = texts.productsSection.players;

    const prevSlide = () => {
        const isFirstSlide = currentIndex === 0;
        const newIndex = isFirstSlide ? trainingProgramImages.length - 1 : currentIndex - 1;
        setCurrentIndex(newIndex);
    };

    const nextSlide = () => {
        const isLastSlide = currentIndex === trainingProgramImages.length - 1;
        const newIndex = isLastSlide ? 0 : currentIndex + 1;
        setCurrentIndex(newIndex);
    };

    const goToSlide = (slideIndex: number) => {
        setCurrentIndex(slideIndex);
    };

    useEffect(() => {
        const slider = setInterval(() => {
            nextSlide();
        }, 5000);
        return () => clearInterval(slider);
    }, [currentIndex]);
    
    return (
      <div className="bg-gray-50 p-8 md:p-12 rounded-lg shadow-inner animate-fade-in">
        <h3 className="text-3xl font-black text-center text-varese-dark mb-4">{t.title}</h3>
        <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto">
          {t.description}
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.target.title}</p>
                <p className="text-gray-700 mt-1">{t.target.details}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.timing.title}</p>
                <p className="text-gray-700 mt-1">{t.timing.details}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.opportunity.title}</p>
                <p className="text-gray-700 mt-1">{t.opportunity.details}</p>
            </div>
        </div>
        
        <div className="mt-16">
             <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.completeOffer.title}</h4>
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                 {t.completeOffer.pillars.map(pillar => (
                     <div key={pillar.title} className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300">
                        <div className="flex-shrink-0 mb-4">
                            {pillar.title === 'Elite Basketball' || pillar.title === 'Pallacanestro d\'Elitè' ? <BasketballIcon className="h-10 w-10 text-varese-red" /> : 
                             pillar.title === 'Holistic Education' || pillar.title === 'Istruzione Olistica' ? <EducationIcon className="h-10 w-10 text-varese-red" /> : 
                             <BedIcon className="h-10 w-10 text-varese-red" />}
                        </div>
                        <h5 className="text-xl font-bold text-varese-dark">{pillar.title}</h5>
                        <p className="mt-2 text-gray-600 flex-grow">{pillar.description}</p>
                     </div>
                 ))}
             </div>
        </div>

        <div className="mt-20">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-10">{t.trainingProgram.title}</h4>
          <div className="grid grid-cols-1 lg:grid-cols-3 items-center gap-8">
            <div className="space-y-6 text-right">
              {t.trainingProgram.pillars.slice(0, 3).map(pillar => (
                <div key={pillar.title} className="group">
                  <h5 className="font-bold text-lg text-varese-dark">{pillar.title}</h5>
                  <p className="text-gray-500 text-sm">{pillar.details}</p>
                </div>
              ))}
            </div>

            <div className="my-8 lg:my-0 h-96 w-full relative group rounded-lg overflow-hidden shadow-lg">
                {trainingProgramImages.map((src, index) => (
                    <img
                        key={src}
                        src={src}
                        alt={`${t.trainingProgram.title} showcase ${index + 1}`}
                        loading="lazy"
                        decoding="async"
                        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-in-out ${index === currentIndex ? 'opacity-100' : 'opacity-0'}`}
                        aria-hidden={index !== currentIndex}
                    />
                ))}
                <div className="absolute inset-0 bg-black opacity-10 group-hover:opacity-0 transition-opacity duration-300"></div>

                <button onClick={prevSlide} aria-label={t.prevImageAria} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 left-2 text-2xl rounded-full p-1 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                    <ChevronLeftIcon className="h-6 w-6" />
                </button>
                <button onClick={nextSlide} aria-label={t.nextImageAria} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 right-2 text-2xl rounded-full p-1 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                    <ChevronRightIcon className="h-6 w-6" />
                </button>

                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex justify-center space-x-2">
                    {trainingProgramImages.map((_, slideIndex) => (
                        <button
                            key={slideIndex}
                            onClick={() => goToSlide(slideIndex)}
                            className={`w-2.5 h-2.5 rounded-full transition-colors duration-300 ${currentIndex === slideIndex ? 'bg-varese-red' : 'bg-white/60 hover:bg-white'} focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50`}
                            aria-label={`${t.goToImageAria} ${slideIndex + 1}`}
                            aria-current={currentIndex === slideIndex}
                        ></button>
                    ))}
                </div>
            </div>

            <div className="space-y-6 text-left">
              {t.trainingProgram.pillars.slice(3, 6).map(pillar => (
                <div key={pillar.title} className="group">
                  <h5 className="font-bold text-lg text-varese-dark">{pillar.title}</h5>
                  <p className="text-gray-500 text-sm">{pillar.details}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-10 grid md:grid-cols-3 gap-6 text-center text-gray-700">
              <p dangerouslySetInnerHTML={{ __html: t.trainingProgram.teaching }} />
              <p dangerouslySetInnerHTML={{ __html: t.trainingProgram.personalization }} />
              <p dangerouslySetInnerHTML={{ __html: t.trainingProgram.feedback }} />
          </div>
        </div>

         <div className="mt-20 text-center">
            <h4 className="text-2xl font-bold text-varese-dark mb-8">{t.growthPlan.title}</h4>
            <div className="relative max-w-4xl mx-auto">
                <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-300 -translate-y-1/2"></div>
                <div className="relative flex justify-between">
                    {t.growthPlan.years.map((year, index) => (
                         <div key={year.year} className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full bg-varese-red text-white flex items-center justify-center font-bold border-4 border-gray-50 z-10">{index + 1}</div>
                            <p className="mt-3 font-semibold text-varese-dark">{year.year}</p>
                            <p className="text-sm text-gray-600">{year.players}</p>
                        </div>
                    ))}
                </div>
            </div>
            <p className="mt-6 text-sm text-gray-500 max-w-2xl mx-auto">{t.growthPlan.note}</p>
        </div>

        <div className="mt-20 text-center">
          <h4 className="text-2xl font-bold text-varese-dark">{t.cta.title}</h4>
          <p className="mt-2 text-lg text-gray-600">{t.cta.subtitle}</p>
          <button
            onClick={onInquire}
            className="mt-6 bg-varese-red text-white font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red"
          >
            {t.cta.button}
          </button>
        </div>
      </div>
    );
};

const ProProgram: React.FC<{ onInquire: () => void }> = ({ onInquire }) => {
    const { texts } = useLanguage();
    const t = texts.productsSection.pros;

    return (
      <div className="bg-gray-50 p-8 md:p-12 rounded-lg shadow-inner animate-fade-in">
        <h3 className="text-3xl font-black text-center text-varese-dark mb-4">{t.title}</h3>
        <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto">
          {t.description}
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.target.title}</p>
                <p className="text-gray-700 mt-1">{t.target.details}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.timing.title}</p>
                <p className="text-gray-700 mt-1">{t.timing.details}</p>
            </div>
        </div>
        
        <div className="mt-16">
             <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.included.title}</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                 {t.included.features.map((feature, i) => (
                     <div key={feature.title} className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300">
                        <div className="flex-shrink-0 mb-4">
                            {[<CoachingIcon/>, <BasketballIcon/>, <BarChartIcon/>, <DumbbellIcon/>, <ClockIcon/>, <ScienceIcon/>][i].props.className = "h-10 w-10 text-varese-red"}
                            {[<CoachingIcon className="h-10 w-10 text-varese-red"/>, <BasketballIcon className="h-10 w-10 text-varese-red"/>, <BarChartIcon className="h-10 w-10 text-varese-red"/>, <DumbbellIcon className="h-10 w-10 text-varese-red"/>, <ClockIcon className="h-10 w-10 text-varese-red"/>, <ScienceIcon className="h-10 w-10 text-varese-red"/>][i]}
                        </div>
                        <h5 className="text-xl font-bold text-varese-dark">{feature.title}</h5>
                        <p className="mt-2 text-gray-600 flex-grow">{feature.description}</p>
                     </div>
                 ))}
             </div>
        </div>

        <div className="mt-20 text-center">
          <h4 className="text-2xl font-bold text-varese-dark">{t.cta.title}</h4>
          <p className="mt-2 text-lg text-gray-600">{t.cta.subtitle}</p>
          <button
            onClick={onInquire}
            className="mt-6 bg-varese-red text-white font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red"
          >
            {t.cta.button}
          </button>
        </div>
      </div>
    );
};


const CoachProgram: React.FC<{ onInquire: () => void }> = ({ onInquire }) => {
    const { texts } = useLanguage();
    const t = texts.productsSection.coaches;

    return (
      <div className="bg-gray-50 p-8 md:p-12 rounded-lg shadow-inner animate-fade-in">
        <h3 className="text-3xl font-black text-center text-varese-dark mb-4">{t.title}</h3>
        <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto">
          {t.description}
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.target.title}</p>
                <p className="text-gray-700 mt-1">{t.target.details}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.timing.title}</p>
                <p className="text-gray-700 mt-1">{t.timing.details}</p>
            </div>
        </div>

        <div className="mt-16">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.offer.title}</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {t.offer.items.map(offer => (
              <div key={offer.title} className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300">
                <div className="flex-shrink-0 mb-4">
                    {offer.title === 'Housing' || offer.title === 'Alloggio' ? <BedIcon className="h-10 w-10 text-varese-red" /> : 
                     offer.title === 'Food' || offer.title === 'Vitto' ? <FoodIcon className="h-10 w-10 text-varese-red" /> : 
                     <CoachingIcon className="h-10 w-10 text-varese-red" />}
                </div>
                <h5 className="text-xl font-bold text-varese-dark">{offer.title}</h5>
                <ul className="mt-2 text-gray-600 list-none space-y-1 flex-grow">
                    {offer.details.map(detail => <li key={detail}>{detail}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-16 grid md:grid-cols-2 gap-12 items-start">
            <div>
                <h4 className="text-2xl font-bold text-varese-dark mb-4">{t.experience.title}</h4>
                <ul className="space-y-3 text-gray-700">
                    {t.experience.items.map((item, i) => <li key={i} className="flex"><span className="text-varese-red mr-2 font-bold">›</span>{item}</li>)}
                </ul>
            </div>
             <div>
                <h4 className="text-2xl font-bold text-varese-dark mb-4">{t.results.title}</h4>
                <ul className="space-y-3 text-gray-700">
                    {t.results.items.map((item, i) => <li key={i} className="flex"><span className="text-varese-red mr-2 font-bold">›</span>{item}</li>)}
                </ul>
            </div>
        </div>

        <div className="mt-20 text-center">
          <h4 className="text-2xl font-bold text-varese-dark">{t.cta.title}</h4>
          <p className="mt-2 text-lg text-gray-600">{t.cta.subtitle}</p>
          <button
            onClick={onInquire}
            className="mt-6 bg-varese-red text-white font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red"
          >
            {t.cta.button}
          </button>
        </div>
      </div>
    );
};

const SummerProgram: React.FC<{ onInquire: () => void }> = ({ onInquire }) => {
    const { texts } = useLanguage();
    const t = texts.productsSection.teams;

    return (
      <div className="bg-gray-50 p-8 md:p-12 rounded-lg shadow-inner animate-fade-in">
        <h3 className="text-3xl font-black text-center text-varese-dark mb-4">{t.title}</h3>
        <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto">
          {t.description}
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.target.title}</p>
                <p className="text-gray-700 mt-1">{t.target.details}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.timing.title}</p>
                <p className="text-gray-700 mt-1">{t.timing.details}</p>
            </div>
        </div>
        
        <div className="mt-16">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.baseOffer.title}</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.baseOffer.items.map(offer => (
              <div key={offer.title} className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300">
                <div className="flex-shrink-0 mb-4">
                    {offer.title === "Accommodation" || offer.title === "Alloggio" ? <BedIcon className="h-10 w-10 text-varese-red" /> :
                     offer.title === "Food" || offer.title === "Vitto" ? <FoodIcon className="h-10 w-10 text-varese-red" /> :
                     offer.title === "Facility Exclusivity" || offer.title === "Esclusività della Struttura" ? <BasketballIcon className="h-10 w-10 text-varese-red" /> :
                     <TransportationIcon className="h-10 w-10 text-varese-red" />}
                </div>
                <h5 className="text-xl font-bold text-varese-dark">{offer.title}</h5>
                <ul className="mt-2 text-gray-600 list-none space-y-1 flex-grow">
                    {offer.details.map(detail => <li key={detail}>{detail}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.aLaCarte.title}</h4>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {t.aLaCarte.services.map(service => (
                <div key={service.title} className="bg-white rounded-lg shadow-lg p-6 flex flex-col">
                    <h5 className="text-xl font-bold text-varese-dark">{service.title}</h5>
                    <p className="text-4xl font-black text-varese-red my-2">{service.price}</p>
                    <p className="font-semibold text-gray-600 mb-3">{service.unit}</p>
                    <ul className="text-sm text-gray-500 space-y-1 mt-auto">
                        {service.details.map(detail => <li key={detail}>{detail}</li>)}
                    </ul>
                </div>
            ))}
           </div>
        </div>

        <div className="mt-16">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.addOns.title}</h4>
          <div className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {t.addOns.services.map(service => (
                <div key={service.title} className="bg-white rounded-lg shadow-md p-4 flex justify-between items-center">
                    <span className="font-semibold text-varese-dark">{service.title}</span>
                    <span className="font-bold text-varese-red text-sm bg-red-100 px-3 py-1 rounded-full">{service.price}</span>
                </div>
            ))}
          </div>
           <p className="text-center mt-4 text-gray-500 text-sm">{t.addOns.note}</p>
        </div>

        <div className="mt-20 text-center">
          <h4 className="text-2xl font-bold text-varese-dark">{t.cta.title}</h4>
          <p className="mt-2 text-lg text-gray-600">{t.cta.subtitle}</p>
          <button
            onClick={onInquire}
            className="mt-6 bg-varese-red text-white font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red"
          >
            {t.cta.button}
          </button>
        </div>
      </div>
    );
};

const FrontOfficeProgram: React.FC<{ onInquire: () => void }> = ({ onInquire }) => {
    const { texts } = useLanguage();
    const t = texts.productsSection.frontOffice;

    return (
      <div className="bg-gray-50 p-8 md:p-12 rounded-lg shadow-inner animate-fade-in">
        <h3 className="text-3xl font-black text-center text-varese-dark mb-4">{t.title}</h3>
        <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto">
          {t.description}
        </p>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.target.title}</p>
                <p className="text-gray-700 mt-1">{t.target.details}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-varese-red font-bold text-lg">{t.timing.title}</p>
                <p className="text-gray-700 mt-1">{t.timing.details}</p>
            </div>
        </div>
        
        <div className="mt-16">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.services.title}</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {t.services.items.map(service => (
              <div key={service.title} className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center text-center transform hover:-translate-y-2 transition-transform duration-300">
                <div className="flex-shrink-0 mb-4">
                    {service.title === "Academy" ? <BriefcaseIcon className="h-10 w-10 text-varese-red" /> :
                     service.title === "National Team" || service.title === "Nazionale" ? <GlobeIcon className="h-10 w-10 text-varese-red" /> :
                     <BarChartIcon className="h-10 w-10 text-varese-red" />}
                </div>
                <h5 className="text-xl font-bold text-varese-dark">{service.title}</h5>
                <ul className="mt-2 text-gray-600 list-disc list-inside space-y-1 flex-grow text-left">
                    {service.details.map(detail => <li key={detail}>{detail}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16">
          <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.advantages.title}</h4>
          <div className="max-w-4xl mx-auto space-y-6">
            {t.advantages.items.map(advantage => (
              <div key={advantage.title} className="bg-white rounded-lg shadow-md p-6">
                <h5 className="font-bold text-xl text-varese-dark mb-2">{advantage.title}</h5>
                <p className="text-gray-700">{advantage.description}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-20 text-center">
          <h4 className="text-2xl font-bold text-varese-dark">{t.cta.title}</h4>
          <p className="mt-2 text-lg text-gray-600">{t.cta.subtitle}</p>
          <button
            onClick={onInquire}
            className="mt-6 bg-varese-red text-white font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 shadow-lg focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red"
          >
            {t.cta.button}
          </button>
        </div>
      </div>
    );
};


const ProductsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState('players');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalCategory, setModalCategory] = useState('');
  const { texts } = useLanguage();
  const t = texts.productsSection;

  const handleOpenModal = (category: string) => {
    setModalCategory(category);
    setIsModalOpen(true);
  };
  const handleCloseModal = () => setIsModalOpen(false);


  return (
    <>
      <section id="products" className="py-20 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionTitle title={t.title} subtitle={t.subtitle} />
          
          <div role="tablist" aria-label={t.title} className="mt-12 flex flex-wrap justify-center border-b-2 border-gray-200">
            {t.tabs.map(tab => (
                 <button
                    key={tab.id}
                    id={`tab-${tab.id}`}
                    role="tab"
                    aria-selected={activeTab === tab.id}
                    aria-controls={`tabpanel-${tab.id}`}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-6 py-3 text-lg font-bold transition-colors duration-300 relative rounded-t-md focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-varese-red ${activeTab === tab.id ? 'text-varese-red' : 'text-gray-500 hover:text-varese-dark'}`}
                >
                    {tab.label}
                    {activeTab === tab.id && <span className="absolute bottom-[-2px] left-0 w-full h-1 bg-varese-red"></span>}
                </button>
            ))}
          </div>

          <div className="mt-8">
            <div id="tabpanel-players" role="tabpanel" aria-labelledby="tab-players" hidden={activeTab !== 'players'}>
                {activeTab === 'players' && <PlayerProgram onInquire={() => handleOpenModal(t.tabs[0].label)} />}
            </div>
            <div id="tabpanel-pros" role="tabpanel" aria-labelledby="tab-pros" hidden={activeTab !== 'pros'}>
                {activeTab === 'pros' && <ProProgram onInquire={() => handleOpenModal(t.tabs[1].label)} />}
            </div>
            <div id="tabpanel-coaches" role="tabpanel" aria-labelledby="tab-coaches" hidden={activeTab !== 'coaches'}>
                {activeTab === 'coaches' && <CoachProgram onInquire={() => handleOpenModal(t.tabs[2].label)} />}
            </div>
            <div id="tabpanel-teams" role="tabpanel" aria-labelledby="tab-teams" hidden={activeTab !== 'teams'}>
                {activeTab === 'teams' && <SummerProgram onInquire={() => handleOpenModal(t.tabs[3].label)} />}
            </div>
            <div id="tabpanel-front-office" role="tabpanel" aria-labelledby="tab-front-office" hidden={activeTab !== 'front-office'}>
                {activeTab === 'front-office' && <FrontOfficeProgram onInquire={() => handleOpenModal(t.tabs[4].label)} />}
            </div>
          </div>

        </div>
      </section>
      {isModalOpen && (
        <ContactFormModal category={modalCategory} onClose={handleCloseModal} />
      )}
       <style>{`
          @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fade-in 0.5s ease-out forwards;
          }
       `}</style>
    </>
  );
};

export default ProductsSection;
