

import React from 'react';
import SectionTitle from './SectionTitle';
// FIX: `ProgramFeatures` is not exported from `constants.tsx`. This component is not used in the application.
// Defining `ProgramFeatures` as an empty array to resolve the build error.
const ProgramFeatures: { icon: React.ReactNode; title: string; description: string }[] = [];

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300 transform hover:-translate-y-2">
      <div className="flex-shrink-0 mb-4">
        <div className="flex items-center justify-center h-16 w-16 rounded-full bg-varese-red text-white">
          {icon}
        </div>
      </div>
      <h3 className="text-xl font-bold text-varese-dark mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const ProgramSection: React.FC = () => {
  return (
    <section id="program" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title="Our Program" subtitle="Excellence in Every Detail" />
        <div className="mt-12 grid gap-10 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {ProgramFeatures.map((feature, index) => (
            <FeatureCard key={index} icon={feature.icon} title={feature.title} description={feature.description} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProgramSection;