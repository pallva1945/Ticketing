import React, { useState, useEffect, useRef } from 'react';
import SectionTitle from './SectionTitle';
import { AchievementTrophyIcon, ChevronLeftIcon, ChevronRightIcon } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';

const historyImages = [
  'https://lh3.googleusercontent.com/d/1HfBqeEXv0GgSqHw26TE43TlkytjqZkue',
  'https://lh3.googleusercontent.com/d/1T2YUlrXTWC2f2pxi-vmMnsALXNZj3JIv',
  'https://lh3.googleusercontent.com/d/1xHOccQI6Xy6stJL3aPTom6JvbMj4ll34',
  'https://lh3.googleusercontent.com/d/1kBCFGTo39-0BnbImxA7O-LYu11D7Naym',
  'https://lh3.googleusercontent.com/d/1M_bCHVCKG67WV33Iv8kpDHUx984aVj-j',
];

const AboutSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { texts } = useLanguage();
  const { title, subtitle, sectionTitle, content, achievements, legacy } = texts.aboutSection;

  const prevSlide = () => {
    const isFirstSlide = currentIndex === 0;
    const newIndex = isFirstSlide ? historyImages.length - 1 : currentIndex - 1;
    setCurrentIndex(newIndex);
  };

  const nextSlide = () => {
    const isLastSlide = currentIndex === historyImages.length - 1;
    const newIndex = isLastSlide ? 0 : currentIndex + 1;
    setCurrentIndex(newIndex);
  };

  const goToSlide = (slideIndex: number) => {
    setCurrentIndex(slideIndex);
  };

  useEffect(() => {
    const slider = setInterval(() => {
      nextSlide();
    }, 5000); // Change slide every 5 seconds
    return () => clearInterval(slider);
  }, [currentIndex]);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);


  return (
    <section id="about" ref={sectionRef} className="py-20 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title={title} subtitle={subtitle} />
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className={`relative group rounded-lg overflow-hidden shadow-2xl w-full h-[450px] transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            {historyImages.map((src, index) => (
                <img
                    key={src}
                    src={src}
                    alt={`${texts.aboutSection.imageAlt} ${index + 1}`}
                    loading={index === 0 ? 'eager' : 'lazy'}
                    decoding="async"
                    className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-in-out ${index === currentIndex ? 'opacity-100' : 'opacity-0'}`}
                    aria-hidden={index !== currentIndex}
                />
            ))}
            <div className="absolute inset-0 bg-black opacity-10 group-hover:opacity-0 transition-opacity duration-300"></div>

            <button onClick={prevSlide} aria-label={texts.aboutSection.prevImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 left-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-varese-dark">
              <ChevronLeftIcon className="h-8 w-8" />
            </button>
            <button onClick={nextSlide} aria-label={texts.aboutSection.nextImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 right-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-varese-dark">
              <ChevronRightIcon className="h-8 w-8" />
            </button>

            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex justify-center py-2 space-x-2">
              {historyImages.map((_, slideIndex) => (
                <button
                  key={slideIndex}
                  onClick={() => goToSlide(slideIndex)}
                  className={`w-3 h-3 rounded-full transition-colors duration-300 ${currentIndex === slideIndex ? 'bg-varese-red ring-2 ring-offset-2 ring-offset-black/30 ring-varese-red' : 'bg-white/60 hover:bg-white'} focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50`}
                  aria-label={`${texts.aboutSection.goToImage} ${slideIndex + 1}`}
                  aria-current={currentIndex === slideIndex}
                ></button>
              ))}
            </div>
          </div>
          <div className={`transition-all duration-1000 ease-out delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            <h3 className="text-3xl font-bold text-varese-dark mb-4">{sectionTitle}</h3>
            <p className="text-gray-600 mb-4 text-lg">
              {content}
            </p>
            
            <div className="grid grid-cols-2 gap-x-8 gap-y-6 my-6">
                {achievements.map((ach, index) => (
                    <div key={index} className="flex items-start">
                        <AchievementTrophyIcon className="h-10 w-10 text-varese-red mr-4 flex-shrink-0 mt-1" />
                        <div>
                            <p className="text-4xl font-black text-varese-dark leading-none">{ach.count}</p>
                            <p className="text-sm font-semibold text-gray-500 uppercase tracking-wider">{ach.title}</p>
                        </div>
                    </div>
                ))}
            </div>

            <p className="text-gray-600 mb-6 text-lg">
              {legacy}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
