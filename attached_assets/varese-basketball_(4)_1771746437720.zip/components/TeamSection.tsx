import React, { useState, useEffect, useRef } from 'react';
import SectionTitle from './SectionTitle';
import { useLanguage } from '../contexts/LanguageContext';

interface TeamMemberCardProps {
  name: string;
  role: string;
  imageUrl: string;
  description: string;
}

const TeamMemberCard: React.FC<TeamMemberCardProps> = ({ name, role, imageUrl, description }) => {
  return (
    <div className="text-center group">
      <div className="relative w-48 h-48 mx-auto rounded-full overflow-hidden shadow-lg transform group-hover:scale-105 transition-transform duration-300">
        <img className="object-cover w-full h-full" src={imageUrl} alt={name} loading="lazy" decoding="async" />
        <div className="absolute inset-0 bg-varese-red opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
      </div>
      <h3 className="mt-4 text-xl font-bold text-varese-dark">{name}</h3>
      <p className="text-varese-red font-semibold">{role}</p>
      <p className="mt-2 text-sm text-gray-600">{description}</p>
    </div>
  );
};

const TeamSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { texts } = useLanguage();
  const { title, subtitle, intro, seniorAdvisorsTitle, eliteLeadershipTitle, SeniorAdvisors, EliteLeadership } = texts.teamSection;

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section id="team" ref={sectionRef} className="py-20 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title={title} subtitle={subtitle} />
        
        <div className={`mt-8 max-w-4xl mx-auto text-center text-lg text-gray-600 space-y-4 transition-all duration-700 ease-out delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <p>
            {intro.p1}
          </p>
          <p>
            {intro.p2}
          </p>
        </div>

        <div className={`mt-16 transition-all duration-700 ease-out delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <h3 className="text-3xl font-bold text-center text-varese-dark mb-12">{seniorAdvisorsTitle}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12 max-w-5xl mx-auto">
            {SeniorAdvisors.map((member, index) => (
              <TeamMemberCard key={index} name={member.name} role={member.role} imageUrl={member.imageUrl} description={member.description} />
            ))}
          </div>
        </div>

        <div className={`mt-20 transition-all duration-700 ease-out delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <h3 className="text-3xl font-bold text-center text-varese-dark mb-12">{eliteLeadershipTitle}</h3>
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-12">
            {EliteLeadership.map((member, index) => (
              <TeamMemberCard key={index} name={member.name} role={member.role} imageUrl={member.imageUrl} description={member.description} />
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

export default TeamSection;
