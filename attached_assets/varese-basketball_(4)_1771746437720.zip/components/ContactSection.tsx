import React, { useState, useEffect, useRef } from 'react';
import SectionTitle from './SectionTitle';
import { MailIcon, PhoneIcon, CloseIcon } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';

// Contact Form Modal Component
interface ContactFormModalProps {
  category: string;
  onClose: () => void;
}

const ContactFormModal: React.FC<ContactFormModalProps> = ({ category, onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { texts } = useLanguage();
  const t = texts.contactSection.modal;


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({ category, name, email, message });
    // In a real app, you would send this data to a server
    setIsSubmitted(true);
    setTimeout(() => {
        onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-2xl p-8 max-w-lg w-full relative transform transition-all duration-300 ease-in-out scale-95 animate-scale-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors rounded-full focus-visible:ring-2 focus-visible:ring-varese-red focus-visible:ring-offset-2"
          aria-label={t.closeAriaLabel}
        >
          <CloseIcon className="h-6 w-6" />
        </button>
        
        {isSubmitted ? (
            <div className="text-center py-8">
                <h3 className="text-2xl font-bold text-varese-dark mb-2">{t.thankYou}</h3>
                <p className="text-gray-600">{t.submittedMsg}</p>
            </div>
        ) : (
            <>
                <h3 className="text-2xl font-bold text-varese-dark mb-2">{t.title}</h3>
                <p className="text-varese-red font-semibold mb-6">{t.inquiryType} {category}</p>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">{t.nameLabel}</label>
                    <input
                      type="text"
                      name="name"
                      id="name"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-varese-red focus:border-varese-red"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">{t.emailLabel}</label>
                    <input
                      type="email"
                      name="email"
                      id="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-varese-red focus:border-varese-red"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700">{t.messageLabel}</label>
                    <textarea
                      name="message"
                      id="message"
                      rows={4}
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-varese-red focus:border-varese-red"
                    />
                  </div>
                  <div>
                    <button
                      type="submit"
                      className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-varese-red hover:bg-red-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red transition-colors"
                    >
                      {t.submitButton}
                    </button>
                  </div>
                </form>
            </>
        )}
      </div>
       <style>{`
          @keyframes scale-in {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          .animate-scale-in {
            animation: scale-in 0.2s ease-out forwards;
          }
       `}</style>
    </div>
  );
};


const ContactSection: React.FC = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [contactCategory, setContactCategory] = useState<string | null>(null);
    const sectionRef = useRef<HTMLDivElement>(null);
    const [isVisible, setIsVisible] = useState(false);
    const { texts } = useLanguage();
    const t = texts.contactSection;

    const handleCategoryClick = (category: string) => {
        setContactCategory(category);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setTimeout(() => setContactCategory(null), 300); 
    };

    useEffect(() => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.unobserve(entry.target);
          }
        },
        { threshold: 0.1 }
      );
  
      if (sectionRef.current) {
        observer.observe(sectionRef.current);
      }
  
      return () => {
        if (sectionRef.current) {
          observer.unobserve(sectionRef.current);
        }
      };
    }, []);

  return (
    <>
      <section id="contact" ref={sectionRef} className="py-20 bg-white overflow-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <SectionTitle title={t.title} subtitle={t.subtitle} />
          <p className={`mt-6 text-lg text-gray-600 max-w-3xl mx-auto transition-all duration-700 ease-out delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            {t.description}
          </p>
          
          <div className={`mt-10 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 max-w-4xl mx-auto transition-all duration-700 ease-out delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              {t.categories.map(category => (
                  <button 
                      key={category} 
                      onClick={() => handleCategoryClick(category)}
                      className="p-6 bg-gray-50 rounded-lg shadow-md hover:shadow-xl hover:bg-varese-red hover:text-white transition-all duration-300 transform hover:-translate-y-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red"
                  >
                      <span className="text-lg font-bold">{category}</span>
                  </button>
              ))}
          </div>

          <div className={`mt-12 flex flex-col md:flex-row justify-center items-center space-y-6 md:space-y-0 md:space-x-12 transition-all duration-700 ease-out delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            <div className="flex items-center text-lg">
              <MailIcon className="h-8 w-8 text-varese-red mr-3" />
              <a href="mailto:info@pallacanestrovares.it" className="text-gray-800 hover:text-varese-red transition-colors rounded-md focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red">
                info@pallacanestrovares.it
              </a>
            </div>
            <div className="flex items-center text-lg">
              <PhoneIcon className="h-8 w-8 text-varese-red mr-3" />
              <a href="tel:+390332240990" className="text-gray-800 hover:text-varese-red transition-colors rounded-md focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red">
                +39 0332 240 990
              </a>
            </div>
          </div>
        </div>
      </section>
      {isModalOpen && contactCategory && (
          <ContactFormModal category={contactCategory} onClose={handleCloseModal} />
      )}
    </>
  );
};

export default ContactSection;
