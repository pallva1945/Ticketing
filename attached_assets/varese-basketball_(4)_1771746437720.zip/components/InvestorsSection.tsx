

import React from 'react';
import SectionTitle from './SectionTitle';
// FIX: `InvestorPerks` is not exported from `constants.tsx`. This component is not used in the application.
// Defining `InvestorPerks` as an empty array to resolve the build error.
const InvestorPerks: { icon: React.ReactNode; title: string; description: string }[] = [];

const InvestorsSection: React.FC = () => {
  return (
    <section id="investors" className="py-20 bg-varese-dark text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title="For Investors & Sponsors" subtitle="A Partnership in Victory" isDark={true} />
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {InvestorPerks.map((perk, index) => (
                 <div key={index} className="bg-gray-800 p-8 rounded-lg">
                    <div className="flex items-center justify-center h-16 w-16 rounded-full bg-varese-red mx-auto mb-4 text-white">
                        {perk.icon}
                    </div>
                    <h3 className="text-2xl font-bold mb-2">{perk.title}</h3>
                    <p className="text-gray-400">{perk.description}</p>
                </div>
            ))}
        </div>
        <div className="mt-16 text-center">
            <p className="text-xl text-gray-300 mb-6">Ready to align your brand with a legacy of excellence?</p>
            <a href="#contact" className="bg-white text-varese-dark font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-gray-200 transition duration-300 ease-in-out">
                Contact Our Team
            </a>
        </div>
      </div>
    </section>
  );
};

export default InvestorsSection;