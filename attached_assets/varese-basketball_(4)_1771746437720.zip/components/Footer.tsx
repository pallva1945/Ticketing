import React from 'react';
import { PallacanestroVareseLogo, socialLinks } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { texts } = useLanguage();
  return (
    <footer className="bg-varese-dark text-gray-400">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex justify-center mb-8">
            <a href="#" className="rounded-md focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-varese-dark">
              <PallacanestroVareseLogo className="h-20 w-auto" />
            </a>
        </div>
        <div className="flex justify-center space-x-6 mb-8">
          {socialLinks.map((link) => (
            <a key={link.name} href={link.href} className="text-gray-400 hover:text-varese-red transition-colors rounded-full focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-varese-dark p-2">
              <span className="sr-only">{link.name}</span>
              {link.icon}
            </a>
          ))}
        </div>
        <p className="text-center text-base">
          &copy; {new Date().getFullYear()} {texts.footer.copyright}
        </p>
      </div>
    </footer>
  );
};

export default Footer;
