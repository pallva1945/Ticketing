import React, { useState, useEffect, useRef } from 'react';
import SectionTitle from './SectionTitle';
import { OpenjobmetisLogo, PelligraLogo, ItalpreziosiLogo, PumaLogo, LaPrealpinaLogo, LavoraConNoiLogo } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';

const PartnersSection: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { texts } = useLanguage();
  const t = texts.partnersSection;

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, []);

  const logos = [
    { component: OpenjobmetisLogo, href: "#" },
    { component: PelligraLogo, href: "#" },
    { component: ItalpreziosiLogo, href: "#" },
    { component: PumaLogo, href: "#" },
    { component: LaPrealpinaLogo, href: "#" },
    { component: LavoraConNoiLogo, href: "#" },
  ];

  return (
    <section id="sponsors" className="py-20 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title={t.title} subtitle={t.subtitle} />
        <div ref={ref} className="mt-12 flex justify-center items-center gap-12 md:gap-20 flex-wrap">
          {logos.map((logo, index) => (
            <div key={index} className={`transition-all duration-500 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`} style={{ transitionDelay: `${index * 100}ms`}}>
               <a href={logo.href} target="_blank" rel="noopener noreferrer" className="transition-all duration-300 filter grayscale hover:grayscale-0 focus-visible:grayscale-0 focus-visible:ring-2 focus-visible:ring-varese-red focus-visible:ring-offset-2 rounded-md">
                <logo.component className="h-14 md:h-16 w-auto" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PartnersSection;
