import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

const Hero: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { texts } = useLanguage();

  useEffect(() => {
    // Trigger animation after the component mounts to ensure it's visible
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section id="home" className="relative h-screen flex items-center justify-center text-center text-white overflow-hidden">
      <img
        src="https://lh3.googleusercontent.com/d/1yZns9oSXUMlhviMD1LD9EPcaG9krvj46"
        alt={texts.hero.imageAlt}
        className="absolute top-0 left-0 w-full h-full object-cover z-0"
      />
      <div className="absolute top-0 left-0 w-full h-full bg-varese-dark opacity-70 z-10"></div>
      <div className="relative z-20 p-8">
        <h1
          className={`text-5xl md:text-7xl font-black uppercase tracking-wider mb-4 transition-all duration-1000 ease-out ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
          style={{ textShadow: '0 3px 6px rgba(0,0,0,0.7)' }}
        >
          {texts.hero.title.part1}
          <span className="text-varese-red">{texts.hero.title.highlight}</span>
          {texts.hero.title.part2}
        </h1>
        <p
          className={`text-lg md:text-2xl font-light max-w-3xl mx-auto transition-all duration-1000 ease-out delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
          style={{ textShadow: '0 2px 4px rgba(0,0,0,0.6)' }}
        >
          {texts.hero.subtitle}
        </p>
      </div>
    </section>
  );
};

export default Hero;
