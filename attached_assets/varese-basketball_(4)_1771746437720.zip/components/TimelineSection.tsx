import React, { useState, useEffect, useRef } from 'react';
import SectionTitle from './SectionTitle';
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  PlayIcon,
  DownloadIcon
} from '../constants';
import { useLanguage } from '../contexts/LanguageContext';

const facilityRenderImages = [
    'https://lh3.googleusercontent.com/d/1UbF6oeto-IHCG1eYtvoqZqWP7ECx5sIq',
    'https://lh3.googleusercontent.com/d/1ieIlyYM_Gt673meDi5BK57nfNCOQX6HA',
    'https://lh3.googleusercontent.com/d/1OC5GIqOyS3pP-9pO0DWQPUo2_KjaRGMn',
    'https://lh3.googleusercontent.com/d/1KjWw70qNLr2wt9KahLeZW_JYKIJ0IuYi',
    'https://lh3.googleusercontent.com/d/1dvUb3DmvuaI-uNFWHhJDgZVD_pvteuH3',
    'https://lh3.googleusercontent.com/d/1pYg_tm5eL2X5L68Qii1y1-Re6VJ_M2OE',
];

const trainingCenterImages = [
  'https://lh3.googleusercontent.com/d/1G-liLveC1_3DyA8MRav9rMMOCXWhDBVM',
  'https://lh3.googleusercontent.com/d/1UZQf46XlsGTYjI5TV2ktc2feSU0WtHU9',
  'https://lh3.googleusercontent.com/d/119ewkXzaigtXa7_yG6zg1JPl1Rpvn2uc',
  'https://lh3.googleusercontent.com/d/1PkTkP7ES9avzuGd1x4OGwX0CquDCjLG2',
  'https://lh3.googleusercontent.com/d/1DKx_fen1pQHsrenS-psorT4dfRSJBA4d',
];

const residenceImages = [
  'https://i.imgur.com/u8HaFwI.jpg',
  'https://lh3.googleusercontent.com/d/1hq1tbPBwcENi7Mg-M6VLhBGtikkjaT2A',
  'https://lh3.googleusercontent.com/d/1eP7eHxXyEA3lI0SDh29D3BJloXTwwO9A',
  'https://lh3.googleusercontent.com/d/1QxjCFpgD8AFZgx-NjaFJNYTS1HgViLTE',
  'https://lh3.googleusercontent.com/d/1GY1kiLzt9u9wyCi5Ppk6AN9aff2ajh2j',
];


const MethodStepCard: React.FC<{ step: any }> = ({ step }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const hasImages = step.images && step.images.length > 0;
    const ref = useRef<HTMLDivElement>(null);
    const [isVisible, setIsVisible] = useState(false);
    const { texts } = useLanguage();

    useEffect(() => {
        const observer = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting) {
                setIsVisible(true);
                observer.unobserve(entry.target);
            }
        }, { threshold: 0.1 });

        if (ref.current) observer.observe(ref.current);
        return () => { if (ref.current) observer.unobserve(ref.current); };
    }, []);

    const prevSlide = () => {
        const isFirstSlide = currentIndex === 0;
        const newIndex = isFirstSlide ? (step.images?.length ?? 1) - 1 : currentIndex - 1;
        setCurrentIndex(newIndex);
    };

    const nextSlide = () => {
        const isLastSlide = currentIndex === (step.images?.length ?? 1) - 1;
        const newIndex = isLastSlide ? 0 : currentIndex + 1;
        setCurrentIndex(newIndex);
    };

    const goToSlide = (slideIndex: number) => {
        setCurrentIndex(slideIndex);
    };
    
    return (
        <div ref={ref} className={`bg-white rounded-lg shadow-lg flex flex-col hover:shadow-2xl transition-all duration-500 ease-out transform hover:-translate-y-1 overflow-hidden ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            <div className="relative group w-full h-56 bg-gray-200 flex items-center justify-center">
                {hasImages ? (
                    <>
                        {step.images.map((src: string, index: number) => (
                             <img
                                key={src}
                                src={src}
                                alt={`${step.title} example ${index + 1}`}
                                loading="lazy"
                                decoding="async"
                                className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-in-out ${index === currentIndex ? 'opacity-100' : 'opacity-0'}`}
                                aria-hidden={index !== currentIndex}
                            />
                        ))}
                         {(step.images.length ?? 0) > 1 && (
                            <>
                                <button onClick={prevSlide} aria-label={texts.timelineSection.prevImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 left-2 text-2xl rounded-full p-1 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                                    <ChevronLeftIcon className="h-6 w-6" />
                                </button>
                                <button onClick={nextSlide} aria-label={texts.timelineSection.nextImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 right-2 text-2xl rounded-full p-1 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                                    <ChevronRightIcon className="h-6 w-6" />
                                </button>
                                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex justify-center space-x-2">
                                    {step.images.map((_: any, slideIndex: number) => (
                                        <button
                                            key={slideIndex}
                                            onClick={() => goToSlide(slideIndex)}
                                            className={`w-2.5 h-2.5 rounded-full transition-colors duration-300 ${currentIndex === slideIndex ? 'bg-varese-red' : 'bg-white/60 hover:bg-white'} focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50`}
                                            aria-label={`${texts.timelineSection.goToImage} ${slideIndex + 1}`}
                                            aria-current={currentIndex === slideIndex}
                                        ></button>
                                    ))}
                                </div>
                            </>
                        )}
                    </>
                ) : (
                    <div className="text-varese-red/50">{React.cloneElement(step.icon as React.ReactElement<{ className?: string }>, { className: "h-20 w-20" })}</div>
                )}
            </div>
            <div className="p-6 text-center flex flex-col items-center flex-grow">
                <h4 className="text-xl font-bold text-varese-dark mb-2">{texts.timelineSection.ourMethod.everyday}... {step.title}</h4>
                <p className="text-gray-600 flex-grow">{step.description}</p>
            </div>
        </div>
    );
};

const AnimatedDiv: React.FC<{children: React.ReactNode, className?: string, delay?: string}> = ({ children, className, delay = 'delay-0' }) => {
    const ref = useRef<HTMLDivElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const observer = new IntersectionObserver(([entry]) => {
            if (entry.isIntersecting) {
                setIsVisible(true);
                observer.unobserve(entry.target);
            }
        }, { threshold: 0.1 });

        if (ref.current) observer.observe(ref.current);
        return () => { if (ref.current) observer.unobserve(ref.current); };
    }, []);
    
    return (
        <div ref={ref} className={`${className} transition-all duration-700 ease-out ${delay} ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}>
            {children}
        </div>
    );
};

const TimelineSection: React.FC = () => {
  const [residenceImageIndex, setResidenceImageIndex] = useState(0);
  const [trainingCenterImageIndex, setTrainingCenterImageIndex] = useState(0);
  const [facilityRenderIndex, setFacilityRenderIndex] = useState(0);
  const { texts } = useLanguage();
  const t = texts.timelineSection;

  const prevResidenceSlide = () => {
    const isFirstSlide = residenceImageIndex === 0;
    const newIndex = isFirstSlide ? residenceImages.length - 1 : residenceImageIndex - 1;
    setResidenceImageIndex(newIndex);
  };

  const nextResidenceSlide = () => {
    const isLastSlide = residenceImageIndex === residenceImages.length - 1;
    const newIndex = isLastSlide ? 0 : residenceImageIndex + 1;
    setResidenceImageIndex(newIndex);
  };
  
  const goToResidenceSlide = (slideIndex: number) => {
    setResidenceImageIndex(slideIndex);
  };

  const prevTrainingCenterSlide = () => {
    const isFirstSlide = trainingCenterImageIndex === 0;
    const newIndex = isFirstSlide ? trainingCenterImages.length - 1 : trainingCenterImageIndex - 1;
    setTrainingCenterImageIndex(newIndex);
  };

  const nextTrainingCenterSlide = () => {
    const isLastSlide = trainingCenterImageIndex === trainingCenterImages.length - 1;
    const newIndex = isLastSlide ? 0 : trainingCenterImageIndex + 1;
    setTrainingCenterImageIndex(newIndex);
  };
  
  const goToTrainingCenterSlide = (slideIndex: number) => {
    setTrainingCenterImageIndex(slideIndex);
  };

  const prevFacilityRenderSlide = () => {
    const isFirstSlide = facilityRenderIndex === 0;
    const newIndex = isFirstSlide ? facilityRenderImages.length - 1 : facilityRenderIndex - 1;
    setFacilityRenderIndex(newIndex);
  };

  const nextFacilityRenderSlide = () => {
    const isLastSlide = facilityRenderIndex === facilityRenderImages.length - 1;
    const newIndex = isLastSlide ? 0 : facilityRenderIndex + 1;
    setFacilityRenderIndex(newIndex);
  };
  
  const goToFacilityRenderSlide = (slideIndex: number) => {
    setFacilityRenderIndex(slideIndex);
  };


  useEffect(() => {
    const residenceSlider = setInterval(nextResidenceSlide, 5000);
    const trainingSlider = setInterval(nextTrainingCenterSlide, 5000);
    const facilitySlider = setInterval(nextFacilityRenderSlide, 5500);

    return () => {
        clearInterval(residenceSlider);
        clearInterval(trainingSlider);
        clearInterval(facilitySlider);
    }
  }, [residenceImageIndex, trainingCenterImageIndex, facilityRenderIndex]);


  return (
    <section id="journey" className="py-20 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle title={t.title} subtitle={t.subtitle} />

        {/* WHERE WE STARTED */}
        <div className="mt-16 grid md:grid-cols-2 gap-12 items-center">
          <AnimatedDiv>
            <div className="pr-8">
              <h3 className="text-3xl font-bold text-varese-dark mb-4">{t.started.title}</h3>
              <p className="text-gray-600 text-lg mb-4">{t.started.p1}</p>
              <p className="text-gray-600 text-lg">{t.started.p2}</p>
            </div>
          </AnimatedDiv>
          <AnimatedDiv delay="delay-200">
            <div className="w-full aspect-video rounded-lg overflow-hidden shadow-xl">
              <img
                src="https://lh3.googleusercontent.com/d/1gw1xcvdf6hgLNJfVptLrec3Vbh1sJGlX"
                alt={t.started.imageAlt}
                className="w-full h-full object-cover object-center"
                loading="lazy"
                decoding="async"
              />
            </div>
          </AnimatedDiv>
        </div>

        {/* WHERE WE ARE */}
        <div className="mt-24">
            <AnimatedDiv>
                <h3 className="text-center text-3xl font-bold text-varese-dark mb-12">{t.are.title}</h3>
            </AnimatedDiv>

          {/* Infrastructure */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <AnimatedDiv>
                <div className="group relative rounded-lg overflow-hidden shadow-xl h-80">
                  {trainingCenterImages.map((src, index) => (
                      <img key={src} src={src} alt={`${t.are.trainingCenter.title} image ${index+1}`} loading="lazy" decoding="async" className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${trainingCenterImageIndex === index ? 'opacity-100' : 'opacity-0'}`} />
                  ))}
                  <div className="absolute inset-0 bg-varese-dark opacity-50"></div>
                  <div className="absolute inset-0 p-8 flex flex-col justify-end pointer-events-none">
                    <h4 className="text-2xl font-black text-white">{t.are.trainingCenter.title}</h4>
                    <p className="text-white opacity-90 mt-2">{t.are.trainingCenter.description}</p>
                  </div>
                  
                  <button onClick={prevTrainingCenterSlide} aria-label={t.prevImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 left-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                    <ChevronLeftIcon className="h-6 w-6" />
                  </button>
                  <button onClick={nextTrainingCenterSlide} aria-label={t.nextImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 right-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                    <ChevronRightIcon className="h-6 w-6" />
                  </button>

                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex justify-center py-2 space-x-2">
                    {trainingCenterImages.map((_, slideIndex) => (
                      <button
                        key={slideIndex}
                        onClick={() => goToTrainingCenterSlide(slideIndex)}
                        className={`w-3 h-3 rounded-full transition-colors duration-300 ${trainingCenterImageIndex === slideIndex ? 'bg-varese-red' : 'bg-white/60 hover:bg-white'} focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50`}
                        aria-label={`${t.goToImage} ${slideIndex + 1}`}
                        aria-current={trainingCenterImageIndex === slideIndex}
                      ></button>
                    ))}
                  </div>
                </div>
            </AnimatedDiv>
            <AnimatedDiv delay="delay-200">
                <div className="group relative rounded-lg overflow-hidden shadow-xl h-80">
                  {residenceImages.map((src, index) => (
                      <img key={src} src={src} alt={`${t.are.residence.title} image ${index+1}`} loading="lazy" decoding="async" className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${residenceImageIndex === index ? 'opacity-100' : 'opacity-0'}`} />
                  ))}
                  <div className="absolute inset-0 bg-varese-dark opacity-50"></div>
                  <div className="absolute inset-0 p-8 flex flex-col justify-end pointer-events-none">
                    <h4 className="text-2xl font-black text-white">{t.are.residence.title}</h4>
                    <p className="text-white opacity-90 mt-2">{t.are.residence.description}</p>
                  </div>
                  
                  <button onClick={prevResidenceSlide} aria-label={t.prevImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 left-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                    <ChevronLeftIcon className="h-6 w-6" />
                  </button>
                  <button onClick={nextResidenceSlide} aria-label={t.nextImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 right-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                    <ChevronRightIcon className="h-6 w-6" />
                  </button>

                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex justify-center py-2 space-x-2">
                    {residenceImages.map((_, slideIndex) => (
                      <button
                        key={slideIndex}
                        onClick={() => goToResidenceSlide(slideIndex)}
                        className={`w-3 h-3 rounded-full transition-colors duration-300 ${residenceImageIndex === slideIndex ? 'bg-varese-red' : 'bg-white/60 hover:bg-white'} focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50`}
                        aria-label={`${t.goToImage} ${slideIndex + 1}`}
                        aria-current={residenceImageIndex === slideIndex}
                      ></button>
                    ))}
                  </div>
                </div>
            </AnimatedDiv>
          </div>
          
          {/* Video Showcase */}
          <AnimatedDiv className="my-16 text-center">
            <h4 className="text-2xl font-bold text-varese-dark mb-8">{t.are.video.title}</h4>
            <div className="relative aspect-video max-w-5xl mx-auto rounded-lg overflow-hidden shadow-2xl">
              <iframe
                className="absolute top-0 left-0 w-full h-full"
                src="https://www.youtube.com/embed/qsmD3z30Bjs?controls=1"
                title={t.are.video.iframeTitle}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
                loading="lazy"
              ></iframe>
            </div>
          </AnimatedDiv>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 my-16 text-center">
            {t.are.journeyStats.map((stat, index) => (
              <AnimatedDiv key={index} delay={`delay-${index*100}`}>
                <div className="bg-white p-6 rounded-lg shadow-lg h-full">
                  <p className="text-5xl font-black text-varese-red">{stat.value}</p>
                  <p className="mt-2 text-lg font-semibold text-varese-dark">{stat.label}</p>
                </div>
              </AnimatedDiv>
            ))}
          </div>

          {/* Data-Driven Approach */}
          <div className="grid md:grid-cols-2 gap-12 my-16 items-center">
            <AnimatedDiv>
              <h4 className="text-2xl font-bold text-varese-dark mb-4">{t.are.dataDriven.title}</h4>
              <p className="text-gray-600 mb-6">{t.are.dataDriven.description}</p>
              <ul className="space-y-4">
                {t.are.dataDriven.features.map((feature, index) => (
                   <li key={index} className="flex items-start">
                    <div className="flex-shrink-0 h-6 w-6 bg-varese-red text-white rounded-full flex items-center justify-center mr-4 mt-1">
                        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                    </div>
                    <span>{feature}</span>
                   </li>
                ))}
              </ul>
            </AnimatedDiv>
            <AnimatedDiv delay="delay-200" className="grid grid-cols-2 gap-4">
              <img src="https://i.imgur.com/Z8yTdTC.png" alt={t.are.dataDriven.imageAlt1} className="rounded-lg shadow-md w-full object-cover" loading="lazy" decoding="async"/>
              <img src="https://i.imgur.com/aqb8ON6.png" alt={t.are.dataDriven.imageAlt2} className="rounded-lg shadow-md w-full object-cover mt-8" loading="lazy" decoding="async"/>
            </AnimatedDiv>
          </div>

          {/* Pro Players */}
          <AnimatedDiv className="my-16">
            <h4 className="text-2xl font-bold text-varese-dark text-center mb-8">{t.are.proPlayers.title}</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 text-center">
              {t.are.proPlayers.players.map((player, index) => (
                <div key={index} className="bg-white p-4 rounded-lg shadow-lg">
                  <p className="font-bold text-lg text-varese-dark">{player.name}</p>
                  <p className="text-sm font-semibold text-varese-red">{player.team}</p>
                </div>
              ))}
            </div>
             <p className="text-center mt-4 text-gray-500">{t.are.proPlayers.footer}</p>
          </AnimatedDiv>
        </div>
        
        {/* WHAT'S NEXT */}
        <div className="my-24">
            <SectionTitle title={t.next.title} subtitle={t.next.subtitle} />

            <AnimatedDiv className="mt-12 bg-white p-8 rounded-lg shadow-xl border-t-4 border-varese-red">
                <div className="grid md:grid-cols-2 gap-8 items-center">
                    <div>
                        <span className="bg-varese-red text-white text-sm font-bold uppercase px-3 py-1.5 rounded-md shadow-lg">{t.next.lab.tag}</span>
                        <h3 className="text-3xl font-bold text-varese-dark mt-4 mb-4">{t.next.lab.title}</h3>
                        <p className="text-gray-600 mb-6">
                           {t.next.lab.description}
                        </p>
                        <div>
                            <h4 className="font-semibold text-varese-dark">{t.next.lab.funding.title}</h4>
                            <div className="w-full bg-gray-200 rounded-full h-2.5 my-2 overflow-hidden">
                                <div className="bg-varese-red h-2.5 rounded-full" style={{width: '70%'}}></div>
                            </div>
                            <p className="text-sm text-gray-500">
                                {t.next.lab.funding.description}
                            </p>
                        </div>
                        <div className="mt-6">
                            <a 
                                href="Ivolution_Lab_Brochure.pdf" 
                                download="Ivolution_Lab_Brochure.pdf"
                                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-varese-red hover:bg-red-700 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red focus-visible:ring-offset-white"
                            >
                                <DownloadIcon className="h-5 w-5 mr-3" />
                                {t.next.lab.downloadButton}
                            </a>
                        </div>
                    </div>
                    <div>
                         <a 
                            href="https://www.instagram.com/reel/C9KhZtnApMX/" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="group relative aspect-video rounded-lg overflow-hidden shadow-2xl block focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-varese-red focus-visible:ring-offset-white"
                            aria-label={t.next.lab.reelAriaLabel}
                        >
                            <img src="https://i.imgur.com/qfJ8HAq.jpeg" alt={t.next.lab.imageAlt} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" decoding="async"/>
                            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent group-hover:bg-black/20 transition-all duration-300"></div>
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="bg-white/30 backdrop-blur-sm rounded-full p-4 group-hover:bg-varese-red transition-colors duration-300 transform group-hover:scale-110">
                                <PlayIcon className="h-12 w-12 text-white" />
                                </div>
                            </div>
                            <div className="absolute bottom-4 left-4"><span className="bg-varese-red text-white text-sm font-bold uppercase px-3 py-1.5 rounded-md shadow-lg">{t.next.lab.reelButton}</span></div>
                        </a>
                        <div className="grid grid-cols-3 gap-2 mt-4">
                            <img src="https://i.imgur.com/xaIpd2I.jpeg" alt={`${t.next.lab.imageAlt} 1`} className="w-full h-full object-cover rounded-md shadow-lg" loading="lazy" decoding="async" />
                            <img src="https://i.imgur.com/qfJ8HAq.jpeg" alt={`${t.next.lab.imageAlt} 2`} className="w-full h-full object-cover rounded-md shadow-lg" loading="lazy" decoding="async" />
                            <img src="https://i.imgur.com/ZAdVM9B.jpeg" alt={`${t.next.lab.imageAlt} 3`} className="w-full h-full object-cover rounded-md shadow-lg" loading="lazy" decoding="async" />
                        </div>
                    </div>
                </div>
            </AnimatedDiv>

            <AnimatedDiv className="mt-20 text-center">
                <h3 className="text-4xl font-black text-varese-dark mb-4">{t.next.vision.title}</h3>
                <p className="text-lg text-gray-600 max-w-4xl mx-auto mb-10">
                   {t.next.vision.description}
                </p>

                 <div className="relative group rounded-lg overflow-hidden shadow-2xl max-w-5xl mx-auto">
                    <div className="aspect-[16/10]">
                        {facilityRenderImages.map((src, index) => (
                            <img key={src} src={src} alt={`${t.next.vision.renderAlt} ${index+1}`} loading="lazy" decoding="async" className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${facilityRenderIndex === index ? 'opacity-100' : 'opacity-0'}`} />
                        ))}
                    </div>
                    <div className="absolute inset-0 bg-black/10"></div>
                    
                    <button onClick={prevFacilityRenderSlide} aria-label={t.prevImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 left-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                        <ChevronLeftIcon className="h-8 w-8" />
                    </button>
                    <button onClick={nextFacilityRenderSlide} aria-label={t.nextImage} className="hidden group-hover:block absolute top-1/2 -translate-y-1/2 right-5 text-2xl rounded-full p-2 bg-black/30 text-white cursor-pointer hover:bg-black/50 transition-colors focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50">
                        <ChevronRightIcon className="h-8 w-8" />
                    </button>

                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex justify-center py-2 space-x-2">
                        {facilityRenderImages.map((_, slideIndex) => (
                        <button
                            key={slideIndex}
                            onClick={() => goToFacilityRenderSlide(slideIndex)}
                            className={`w-3 h-3 rounded-full transition-colors duration-300 ${facilityRenderIndex === slideIndex ? 'bg-varese-red ring-2 ring-offset-2 ring-offset-black/30 ring-varese-red' : 'bg-white/60 hover:bg-white'} focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-black/50`}
                            aria-label={`${t.goToImage} ${slideIndex + 1}`}
                            aria-current={facilityRenderIndex === slideIndex}
                        ></button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-12 text-left max-w-5xl mx-auto items-start">
                    <div className="bg-white p-6 rounded-lg shadow-lg">
                        <h4 className="text-2xl font-bold text-varese-dark mb-4">{t.next.vision.scope.title}</h4>
                        <ul className="space-y-3 text-gray-700 list-disc list-inside">
                            {t.next.vision.scope.items.map((item, i) => <li key={i}>{item}</li>)}
                        </ul>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-lg">
                        <h4 className="text-2xl font-bold text-varese-dark mb-4">{t.next.vision.tech.title}</h4>
                        <p className="text-gray-700">{t.next.vision.tech.description}</p>
                        <p className="text-sm text-gray-500 mt-2">{t.next.vision.tech.metrics}</p>
                        <div className="grid grid-cols-2 gap-2 mt-4">
                            <img src="https://i.imgur.com/7F3d3ns.jpeg" alt={t.next.vision.tech.imageAlt1} className="rounded-md object-cover w-full aspect-square shadow-sm" loading="lazy" decoding="async" />
                            <img src="https://i.imgur.com/1ncKmsF.jpeg" alt={t.next.vision.tech.imageAlt2} className="rounded-md object-cover w-full aspect-square shadow-sm" loading="lazy" decoding="async" />
                            <img src="https://i.imgur.com/zQceN9L.jpeg" alt={t.next.vision.tech.imageAlt3} className="rounded-md object-cover w-full aspect-square shadow-sm" loading="lazy" decoding="async" />
                            <img src="https://i.imgur.com/k3HEPFh.jpeg" alt={t.next.vision.tech.imageAlt4} className="rounded-md object-cover w-full aspect-square shadow-sm" loading="lazy" decoding="async" />
                        </div>
                    </div>
                </div>

                <div className="mt-12 bg-varese-dark text-white p-10 rounded-lg shadow-lg max-w-5xl mx-auto">
                    <h4 className="text-3xl font-black text-center">{t.next.vision.cta.title}</h4>
                    <p className="text-center mt-4 text-lg text-gray-300 max-w-3xl mx-auto">{t.next.vision.cta.description}</p>
                    <div className="mt-8 text-center">
                        <a href="#contact" className="bg-white text-varese-dark font-bold py-4 px-10 text-lg uppercase rounded-md hover:bg-gray-200 transition duration-300 ease-in-out focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white focus-visible:ring-offset-varese-dark">
                           {t.next.vision.cta.button}
                        </a>
                    </div>
                </div>
            </AnimatedDiv>
        </div>


        {/* Our Method */}
        <div className="mt-24">
            <AnimatedDiv>
                <h3 className="text-center text-3xl font-bold text-varese-dark mb-4">{t.ourMethod.title}</h3>
                <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto mb-12">{t.ourMethod.description}</p>
            </AnimatedDiv>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {t.ourMethod.steps.map((step, index) => (
                    <MethodStepCard key={index} step={step} />
                ))}
            </div>
            <AnimatedDiv className="mt-12 text-center text-3xl font-black text-varese-dark tracking-wide">
                <p>{t.ourMethod.everyday}... <span className="text-varese-red">{t.ourMethod.winTheDay}</span></p>
            </AnimatedDiv>
        </div>


        {/* WHERE WE'RE GOING */}
        <AnimatedDiv className="mt-24 text-center bg-varese-dark text-white py-20 px-8 rounded-lg shadow-2xl">
          <h3 className="text-3xl md:text-5xl font-black mb-4">{t.going.title}</h3>
          <p className="text-2xl md:text-3xl font-light max-w-4xl mx-auto text-gray-300"
            dangerouslySetInnerHTML={{ __html: t.going.description }}
           />
        </AnimatedDiv>
      </div>
    </section>
  );
};

export default TimelineSection;
