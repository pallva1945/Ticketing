import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ItalianFlagIcon, UKFlagIcon } from '../constants';

const LanguageSwitcher: React.FC = () => {
  const { language, toggleLanguage, texts } = useLanguage();

  return (
    <button
      onClick={toggleLanguage}
      className="p-2 rounded-full hover:bg-white/10 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
      aria-label={texts.languageSwitcher.ariaLabel}
    >
      {language === 'en' ? (
        <ItalianFlagIcon className="h-6 w-6 rounded-sm" />
      ) : (
        <UKFlagIcon className="h-6 w-6 rounded-sm" />
      )}
    </button>
  );
};

export default LanguageSwitcher;
