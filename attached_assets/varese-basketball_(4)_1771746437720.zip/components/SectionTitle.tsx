import React, { useState, useEffect, useRef } from 'react';

interface SectionTitleProps {
  title: string;
  subtitle: string;
  isDark?: boolean;
}

const SectionTitle: React.FC<SectionTitleProps> = ({ title, subtitle, isDark = false }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          if (ref.current) {
            observer.unobserve(ref.current);
          }
        }
      },
      { threshold: 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, []);

  return (
    <div ref={ref} className={`text-center transition-all duration-700 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
      <h2 className={`text-base font-semibold tracking-wider uppercase ${isDark ? 'text-varese-red' : 'text-varese-red'}`}>
        {subtitle}
      </h2>
      <p className={`mt-2 text-4xl font-black tracking-tight sm:text-5xl ${isDark ? 'text-white' : 'text-varese-dark'}`}>
        {title}
      </p>
    </div>
  );
};

export default SectionTitle;